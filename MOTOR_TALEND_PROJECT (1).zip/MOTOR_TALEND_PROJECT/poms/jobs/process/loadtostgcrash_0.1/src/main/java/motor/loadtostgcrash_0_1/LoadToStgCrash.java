
package motor.loadtostgcrash_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: LoadToStgCrash Purpose: <br>
 * Description: <br>
 * 
 * @author dong.xuej@northeastern.edu
 * @version 8.0.1.20211109_1610
 * @status
 */
public class LoadToStgCrash implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "LoadToStgCrash.log");
	}

	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager
			.getLogger(LoadToStgCrash.class);

	protected static void logIgnoredError(String message, Throwable cause) {
		log.error(message, cause);

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "LoadToStgCrash";
	private final String projectName = "MOTOR";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					LoadToStgCrash.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(LoadToStgCrash.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tBigQueryInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tBigQueryInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tBigQueryInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tBigQueryInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tBigQueryInput_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class outStruct implements routines.system.IPersistableRow<outStruct> {
		final static byte[] commonByteArrayLock_MOTOR_LoadToStgCrash = new byte[0];
		static byte[] commonByteArray_MOTOR_LoadToStgCrash = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public long COLLISION_ID;

		public long getCOLLISION_ID() {
			return this.COLLISION_ID;
		}

		public java.util.Date collision_dt;

		public java.util.Date getCollision_dt() {
			return this.collision_dt;
		}

		public java.util.Date collision_day;

		public java.util.Date getCollision_day() {
			return this.collision_day;
		}

		public java.util.Date collision_time;

		public java.util.Date getCollision_time() {
			return this.collision_time;
		}

		public Integer collision_hour;

		public Integer getCollision_hour() {
			return this.collision_hour;
		}

		public Integer collision_dayoftheweek;

		public Integer getCollision_dayoftheweek() {
			return this.collision_dayoftheweek;
		}

		public String borough;

		public String getBorough() {
			return this.borough;
		}

		public String zip_code;

		public String getZip_code() {
			return this.zip_code;
		}

		public String off_street_name;

		public String getOff_street_name() {
			return this.off_street_name;
		}

		public String on_street_name;

		public String getOn_street_name() {
			return this.on_street_name;
		}

		public String cross_street_name;

		public String getCross_street_name() {
			return this.cross_street_name;
		}

		public String latitude;

		public String getLatitude() {
			return this.latitude;
		}

		public String longitude;

		public String getLongitude() {
			return this.longitude;
		}

		public String location;

		public String getLocation() {
			return this.location;
		}

		public String contributing_factor_vehicle_1;

		public String getContributing_factor_vehicle_1() {
			return this.contributing_factor_vehicle_1;
		}

		public String contributing_factor_vehicle_2;

		public String getContributing_factor_vehicle_2() {
			return this.contributing_factor_vehicle_2;
		}

		public String contributing_factor_vehicle_3;

		public String getContributing_factor_vehicle_3() {
			return this.contributing_factor_vehicle_3;
		}

		public String contributing_factor_vehicle_4;

		public String getContributing_factor_vehicle_4() {
			return this.contributing_factor_vehicle_4;
		}

		public String contributing_factor_vehicle_5;

		public String getContributing_factor_vehicle_5() {
			return this.contributing_factor_vehicle_5;
		}

		public Integer number_of_cyclist_injured;

		public Integer getNumber_of_cyclist_injured() {
			return this.number_of_cyclist_injured;
		}

		public Integer number_of_cyclist_killed;

		public Integer getNumber_of_cyclist_killed() {
			return this.number_of_cyclist_killed;
		}

		public Integer number_of_motorist_injured;

		public Integer getNumber_of_motorist_injured() {
			return this.number_of_motorist_injured;
		}

		public Integer number_of_motorist_killed;

		public Integer getNumber_of_motorist_killed() {
			return this.number_of_motorist_killed;
		}

		public Integer number_of_pedestrians_injured;

		public Integer getNumber_of_pedestrians_injured() {
			return this.number_of_pedestrians_injured;
		}

		public Integer number_of_pedestrians_killed;

		public Integer getNumber_of_pedestrians_killed() {
			return this.number_of_pedestrians_killed;
		}

		public Integer number_of_persons_injured;

		public Integer getNumber_of_persons_injured() {
			return this.number_of_persons_injured;
		}

		public Integer number_of_persons_killed;

		public Integer getNumber_of_persons_killed() {
			return this.number_of_persons_killed;
		}

		public String vehicle_type_code1;

		public String getVehicle_type_code1() {
			return this.vehicle_type_code1;
		}

		public String vehicle_type_code2;

		public String getVehicle_type_code2() {
			return this.vehicle_type_code2;
		}

		public String vehicle_type_code_3;

		public String getVehicle_type_code_3() {
			return this.vehicle_type_code_3;
		}

		public String vehicle_type_code_4;

		public String getVehicle_type_code_4() {
			return this.vehicle_type_code_4;
		}

		public String vehicle_type_code_5;

		public String getVehicle_type_code_5() {
			return this.vehicle_type_code_5;
		}

		public String DI_JobID;

		public String getDI_JobID() {
			return this.DI_JobID;
		}

		public java.util.Date DI_CreateDate;

		public java.util.Date getDI_CreateDate() {
			return this.DI_CreateDate;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.COLLISION_ID;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final outStruct other = (outStruct) obj;

			if (this.COLLISION_ID != other.COLLISION_ID)
				return false;

			return true;
		}

		public void copyDataTo(outStruct other) {

			other.COLLISION_ID = this.COLLISION_ID;
			other.collision_dt = this.collision_dt;
			other.collision_day = this.collision_day;
			other.collision_time = this.collision_time;
			other.collision_hour = this.collision_hour;
			other.collision_dayoftheweek = this.collision_dayoftheweek;
			other.borough = this.borough;
			other.zip_code = this.zip_code;
			other.off_street_name = this.off_street_name;
			other.on_street_name = this.on_street_name;
			other.cross_street_name = this.cross_street_name;
			other.latitude = this.latitude;
			other.longitude = this.longitude;
			other.location = this.location;
			other.contributing_factor_vehicle_1 = this.contributing_factor_vehicle_1;
			other.contributing_factor_vehicle_2 = this.contributing_factor_vehicle_2;
			other.contributing_factor_vehicle_3 = this.contributing_factor_vehicle_3;
			other.contributing_factor_vehicle_4 = this.contributing_factor_vehicle_4;
			other.contributing_factor_vehicle_5 = this.contributing_factor_vehicle_5;
			other.number_of_cyclist_injured = this.number_of_cyclist_injured;
			other.number_of_cyclist_killed = this.number_of_cyclist_killed;
			other.number_of_motorist_injured = this.number_of_motorist_injured;
			other.number_of_motorist_killed = this.number_of_motorist_killed;
			other.number_of_pedestrians_injured = this.number_of_pedestrians_injured;
			other.number_of_pedestrians_killed = this.number_of_pedestrians_killed;
			other.number_of_persons_injured = this.number_of_persons_injured;
			other.number_of_persons_killed = this.number_of_persons_killed;
			other.vehicle_type_code1 = this.vehicle_type_code1;
			other.vehicle_type_code2 = this.vehicle_type_code2;
			other.vehicle_type_code_3 = this.vehicle_type_code_3;
			other.vehicle_type_code_4 = this.vehicle_type_code_4;
			other.vehicle_type_code_5 = this.vehicle_type_code_5;
			other.DI_JobID = this.DI_JobID;
			other.DI_CreateDate = this.DI_CreateDate;

		}

		public void copyKeysDataTo(outStruct other) {

			other.COLLISION_ID = this.COLLISION_ID;

		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MOTOR_LoadToStgCrash.length) {
					if (length < 1024 && commonByteArray_MOTOR_LoadToStgCrash.length == 0) {
						commonByteArray_MOTOR_LoadToStgCrash = new byte[1024];
					} else {
						commonByteArray_MOTOR_LoadToStgCrash = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MOTOR_LoadToStgCrash, 0, length);
				strReturn = new String(commonByteArray_MOTOR_LoadToStgCrash, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MOTOR_LoadToStgCrash.length) {
					if (length < 1024 && commonByteArray_MOTOR_LoadToStgCrash.length == 0) {
						commonByteArray_MOTOR_LoadToStgCrash = new byte[1024];
					} else {
						commonByteArray_MOTOR_LoadToStgCrash = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MOTOR_LoadToStgCrash, 0, length);
				strReturn = new String(commonByteArray_MOTOR_LoadToStgCrash, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MOTOR_LoadToStgCrash) {

				try {

					int length = 0;

					this.COLLISION_ID = dis.readLong();

					this.collision_dt = readDate(dis);

					this.collision_day = readDate(dis);

					this.collision_time = readDate(dis);

					this.collision_hour = readInteger(dis);

					this.collision_dayoftheweek = readInteger(dis);

					this.borough = readString(dis);

					this.zip_code = readString(dis);

					this.off_street_name = readString(dis);

					this.on_street_name = readString(dis);

					this.cross_street_name = readString(dis);

					this.latitude = readString(dis);

					this.longitude = readString(dis);

					this.location = readString(dis);

					this.contributing_factor_vehicle_1 = readString(dis);

					this.contributing_factor_vehicle_2 = readString(dis);

					this.contributing_factor_vehicle_3 = readString(dis);

					this.contributing_factor_vehicle_4 = readString(dis);

					this.contributing_factor_vehicle_5 = readString(dis);

					this.number_of_cyclist_injured = readInteger(dis);

					this.number_of_cyclist_killed = readInteger(dis);

					this.number_of_motorist_injured = readInteger(dis);

					this.number_of_motorist_killed = readInteger(dis);

					this.number_of_pedestrians_injured = readInteger(dis);

					this.number_of_pedestrians_killed = readInteger(dis);

					this.number_of_persons_injured = readInteger(dis);

					this.number_of_persons_killed = readInteger(dis);

					this.vehicle_type_code1 = readString(dis);

					this.vehicle_type_code2 = readString(dis);

					this.vehicle_type_code_3 = readString(dis);

					this.vehicle_type_code_4 = readString(dis);

					this.vehicle_type_code_5 = readString(dis);

					this.DI_JobID = readString(dis);

					this.DI_CreateDate = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MOTOR_LoadToStgCrash) {

				try {

					int length = 0;

					this.COLLISION_ID = dis.readLong();

					this.collision_dt = readDate(dis);

					this.collision_day = readDate(dis);

					this.collision_time = readDate(dis);

					this.collision_hour = readInteger(dis);

					this.collision_dayoftheweek = readInteger(dis);

					this.borough = readString(dis);

					this.zip_code = readString(dis);

					this.off_street_name = readString(dis);

					this.on_street_name = readString(dis);

					this.cross_street_name = readString(dis);

					this.latitude = readString(dis);

					this.longitude = readString(dis);

					this.location = readString(dis);

					this.contributing_factor_vehicle_1 = readString(dis);

					this.contributing_factor_vehicle_2 = readString(dis);

					this.contributing_factor_vehicle_3 = readString(dis);

					this.contributing_factor_vehicle_4 = readString(dis);

					this.contributing_factor_vehicle_5 = readString(dis);

					this.number_of_cyclist_injured = readInteger(dis);

					this.number_of_cyclist_killed = readInteger(dis);

					this.number_of_motorist_injured = readInteger(dis);

					this.number_of_motorist_killed = readInteger(dis);

					this.number_of_pedestrians_injured = readInteger(dis);

					this.number_of_pedestrians_killed = readInteger(dis);

					this.number_of_persons_injured = readInteger(dis);

					this.number_of_persons_killed = readInteger(dis);

					this.vehicle_type_code1 = readString(dis);

					this.vehicle_type_code2 = readString(dis);

					this.vehicle_type_code_3 = readString(dis);

					this.vehicle_type_code_4 = readString(dis);

					this.vehicle_type_code_5 = readString(dis);

					this.DI_JobID = readString(dis);

					this.DI_CreateDate = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// long

				dos.writeLong(this.COLLISION_ID);

				// java.util.Date

				writeDate(this.collision_dt, dos);

				// java.util.Date

				writeDate(this.collision_day, dos);

				// java.util.Date

				writeDate(this.collision_time, dos);

				// Integer

				writeInteger(this.collision_hour, dos);

				// Integer

				writeInteger(this.collision_dayoftheweek, dos);

				// String

				writeString(this.borough, dos);

				// String

				writeString(this.zip_code, dos);

				// String

				writeString(this.off_street_name, dos);

				// String

				writeString(this.on_street_name, dos);

				// String

				writeString(this.cross_street_name, dos);

				// String

				writeString(this.latitude, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.location, dos);

				// String

				writeString(this.contributing_factor_vehicle_1, dos);

				// String

				writeString(this.contributing_factor_vehicle_2, dos);

				// String

				writeString(this.contributing_factor_vehicle_3, dos);

				// String

				writeString(this.contributing_factor_vehicle_4, dos);

				// String

				writeString(this.contributing_factor_vehicle_5, dos);

				// Integer

				writeInteger(this.number_of_cyclist_injured, dos);

				// Integer

				writeInteger(this.number_of_cyclist_killed, dos);

				// Integer

				writeInteger(this.number_of_motorist_injured, dos);

				// Integer

				writeInteger(this.number_of_motorist_killed, dos);

				// Integer

				writeInteger(this.number_of_pedestrians_injured, dos);

				// Integer

				writeInteger(this.number_of_pedestrians_killed, dos);

				// Integer

				writeInteger(this.number_of_persons_injured, dos);

				// Integer

				writeInteger(this.number_of_persons_killed, dos);

				// String

				writeString(this.vehicle_type_code1, dos);

				// String

				writeString(this.vehicle_type_code2, dos);

				// String

				writeString(this.vehicle_type_code_3, dos);

				// String

				writeString(this.vehicle_type_code_4, dos);

				// String

				writeString(this.vehicle_type_code_5, dos);

				// String

				writeString(this.DI_JobID, dos);

				// java.util.Date

				writeDate(this.DI_CreateDate, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// long

				dos.writeLong(this.COLLISION_ID);

				// java.util.Date

				writeDate(this.collision_dt, dos);

				// java.util.Date

				writeDate(this.collision_day, dos);

				// java.util.Date

				writeDate(this.collision_time, dos);

				// Integer

				writeInteger(this.collision_hour, dos);

				// Integer

				writeInteger(this.collision_dayoftheweek, dos);

				// String

				writeString(this.borough, dos);

				// String

				writeString(this.zip_code, dos);

				// String

				writeString(this.off_street_name, dos);

				// String

				writeString(this.on_street_name, dos);

				// String

				writeString(this.cross_street_name, dos);

				// String

				writeString(this.latitude, dos);

				// String

				writeString(this.longitude, dos);

				// String

				writeString(this.location, dos);

				// String

				writeString(this.contributing_factor_vehicle_1, dos);

				// String

				writeString(this.contributing_factor_vehicle_2, dos);

				// String

				writeString(this.contributing_factor_vehicle_3, dos);

				// String

				writeString(this.contributing_factor_vehicle_4, dos);

				// String

				writeString(this.contributing_factor_vehicle_5, dos);

				// Integer

				writeInteger(this.number_of_cyclist_injured, dos);

				// Integer

				writeInteger(this.number_of_cyclist_killed, dos);

				// Integer

				writeInteger(this.number_of_motorist_injured, dos);

				// Integer

				writeInteger(this.number_of_motorist_killed, dos);

				// Integer

				writeInteger(this.number_of_pedestrians_injured, dos);

				// Integer

				writeInteger(this.number_of_pedestrians_killed, dos);

				// Integer

				writeInteger(this.number_of_persons_injured, dos);

				// Integer

				writeInteger(this.number_of_persons_killed, dos);

				// String

				writeString(this.vehicle_type_code1, dos);

				// String

				writeString(this.vehicle_type_code2, dos);

				// String

				writeString(this.vehicle_type_code_3, dos);

				// String

				writeString(this.vehicle_type_code_4, dos);

				// String

				writeString(this.vehicle_type_code_5, dos);

				// String

				writeString(this.DI_JobID, dos);

				// java.util.Date

				writeDate(this.DI_CreateDate, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("COLLISION_ID=" + String.valueOf(COLLISION_ID));
			sb.append(",collision_dt=" + String.valueOf(collision_dt));
			sb.append(",collision_day=" + String.valueOf(collision_day));
			sb.append(",collision_time=" + String.valueOf(collision_time));
			sb.append(",collision_hour=" + String.valueOf(collision_hour));
			sb.append(",collision_dayoftheweek=" + String.valueOf(collision_dayoftheweek));
			sb.append(",borough=" + borough);
			sb.append(",zip_code=" + zip_code);
			sb.append(",off_street_name=" + off_street_name);
			sb.append(",on_street_name=" + on_street_name);
			sb.append(",cross_street_name=" + cross_street_name);
			sb.append(",latitude=" + latitude);
			sb.append(",longitude=" + longitude);
			sb.append(",location=" + location);
			sb.append(",contributing_factor_vehicle_1=" + contributing_factor_vehicle_1);
			sb.append(",contributing_factor_vehicle_2=" + contributing_factor_vehicle_2);
			sb.append(",contributing_factor_vehicle_3=" + contributing_factor_vehicle_3);
			sb.append(",contributing_factor_vehicle_4=" + contributing_factor_vehicle_4);
			sb.append(",contributing_factor_vehicle_5=" + contributing_factor_vehicle_5);
			sb.append(",number_of_cyclist_injured=" + String.valueOf(number_of_cyclist_injured));
			sb.append(",number_of_cyclist_killed=" + String.valueOf(number_of_cyclist_killed));
			sb.append(",number_of_motorist_injured=" + String.valueOf(number_of_motorist_injured));
			sb.append(",number_of_motorist_killed=" + String.valueOf(number_of_motorist_killed));
			sb.append(",number_of_pedestrians_injured=" + String.valueOf(number_of_pedestrians_injured));
			sb.append(",number_of_pedestrians_killed=" + String.valueOf(number_of_pedestrians_killed));
			sb.append(",number_of_persons_injured=" + String.valueOf(number_of_persons_injured));
			sb.append(",number_of_persons_killed=" + String.valueOf(number_of_persons_killed));
			sb.append(",vehicle_type_code1=" + vehicle_type_code1);
			sb.append(",vehicle_type_code2=" + vehicle_type_code2);
			sb.append(",vehicle_type_code_3=" + vehicle_type_code_3);
			sb.append(",vehicle_type_code_4=" + vehicle_type_code_4);
			sb.append(",vehicle_type_code_5=" + vehicle_type_code_5);
			sb.append(",DI_JobID=" + DI_JobID);
			sb.append(",DI_CreateDate=" + String.valueOf(DI_CreateDate));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(COLLISION_ID);

			sb.append("|");

			if (collision_dt == null) {
				sb.append("<null>");
			} else {
				sb.append(collision_dt);
			}

			sb.append("|");

			if (collision_day == null) {
				sb.append("<null>");
			} else {
				sb.append(collision_day);
			}

			sb.append("|");

			if (collision_time == null) {
				sb.append("<null>");
			} else {
				sb.append(collision_time);
			}

			sb.append("|");

			if (collision_hour == null) {
				sb.append("<null>");
			} else {
				sb.append(collision_hour);
			}

			sb.append("|");

			if (collision_dayoftheweek == null) {
				sb.append("<null>");
			} else {
				sb.append(collision_dayoftheweek);
			}

			sb.append("|");

			if (borough == null) {
				sb.append("<null>");
			} else {
				sb.append(borough);
			}

			sb.append("|");

			if (zip_code == null) {
				sb.append("<null>");
			} else {
				sb.append(zip_code);
			}

			sb.append("|");

			if (off_street_name == null) {
				sb.append("<null>");
			} else {
				sb.append(off_street_name);
			}

			sb.append("|");

			if (on_street_name == null) {
				sb.append("<null>");
			} else {
				sb.append(on_street_name);
			}

			sb.append("|");

			if (cross_street_name == null) {
				sb.append("<null>");
			} else {
				sb.append(cross_street_name);
			}

			sb.append("|");

			if (latitude == null) {
				sb.append("<null>");
			} else {
				sb.append(latitude);
			}

			sb.append("|");

			if (longitude == null) {
				sb.append("<null>");
			} else {
				sb.append(longitude);
			}

			sb.append("|");

			if (location == null) {
				sb.append("<null>");
			} else {
				sb.append(location);
			}

			sb.append("|");

			if (contributing_factor_vehicle_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_1);
			}

			sb.append("|");

			if (contributing_factor_vehicle_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_2);
			}

			sb.append("|");

			if (contributing_factor_vehicle_3 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_3);
			}

			sb.append("|");

			if (contributing_factor_vehicle_4 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_4);
			}

			sb.append("|");

			if (contributing_factor_vehicle_5 == null) {
				sb.append("<null>");
			} else {
				sb.append(contributing_factor_vehicle_5);
			}

			sb.append("|");

			if (number_of_cyclist_injured == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_cyclist_injured);
			}

			sb.append("|");

			if (number_of_cyclist_killed == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_cyclist_killed);
			}

			sb.append("|");

			if (number_of_motorist_injured == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_motorist_injured);
			}

			sb.append("|");

			if (number_of_motorist_killed == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_motorist_killed);
			}

			sb.append("|");

			if (number_of_pedestrians_injured == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_pedestrians_injured);
			}

			sb.append("|");

			if (number_of_pedestrians_killed == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_pedestrians_killed);
			}

			sb.append("|");

			if (number_of_persons_injured == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_persons_injured);
			}

			sb.append("|");

			if (number_of_persons_killed == null) {
				sb.append("<null>");
			} else {
				sb.append(number_of_persons_killed);
			}

			sb.append("|");

			if (vehicle_type_code1 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code1);
			}

			sb.append("|");

			if (vehicle_type_code2 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code2);
			}

			sb.append("|");

			if (vehicle_type_code_3 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code_3);
			}

			sb.append("|");

			if (vehicle_type_code_4 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code_4);
			}

			sb.append("|");

			if (vehicle_type_code_5 == null) {
				sb.append("<null>");
			} else {
				sb.append(vehicle_type_code_5);
			}

			sb.append("|");

			if (DI_JobID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_JobID);
			}

			sb.append("|");

			if (DI_CreateDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreateDate);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(outStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.COLLISION_ID, other.COLLISION_ID);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_MOTOR_LoadToStgCrash = new byte[0];
		static byte[] commonByteArray_MOTOR_LoadToStgCrash = new byte[0];

		public String CRASH_DATE;

		public String getCRASH_DATE() {
			return this.CRASH_DATE;
		}

		public String CRASH_TIME;

		public String getCRASH_TIME() {
			return this.CRASH_TIME;
		}

		public String BOROUGH;

		public String getBOROUGH() {
			return this.BOROUGH;
		}

		public String ZIP_CODE;

		public String getZIP_CODE() {
			return this.ZIP_CODE;
		}

		public String LATITUDE;

		public String getLATITUDE() {
			return this.LATITUDE;
		}

		public String LONGITUDE;

		public String getLONGITUDE() {
			return this.LONGITUDE;
		}

		public String LOCATION;

		public String getLOCATION() {
			return this.LOCATION;
		}

		public String ON_STREET_NAME;

		public String getON_STREET_NAME() {
			return this.ON_STREET_NAME;
		}

		public String CROSS_STREET_NAME;

		public String getCROSS_STREET_NAME() {
			return this.CROSS_STREET_NAME;
		}

		public String OFF_STREET_NAME;

		public String getOFF_STREET_NAME() {
			return this.OFF_STREET_NAME;
		}

		public Integer NUMBER_OF_PERSONS_INJURED;

		public Integer getNUMBER_OF_PERSONS_INJURED() {
			return this.NUMBER_OF_PERSONS_INJURED;
		}

		public Integer NUMBER_OF_PERSONS_KILLED;

		public Integer getNUMBER_OF_PERSONS_KILLED() {
			return this.NUMBER_OF_PERSONS_KILLED;
		}

		public Integer NUMBER_OF_PEDESTRIANS_INJURED;

		public Integer getNUMBER_OF_PEDESTRIANS_INJURED() {
			return this.NUMBER_OF_PEDESTRIANS_INJURED;
		}

		public Integer NUMBER_OF_PEDESTRIANS_KILLED;

		public Integer getNUMBER_OF_PEDESTRIANS_KILLED() {
			return this.NUMBER_OF_PEDESTRIANS_KILLED;
		}

		public Integer NUMBER_OF_CYCLIST_INJURED;

		public Integer getNUMBER_OF_CYCLIST_INJURED() {
			return this.NUMBER_OF_CYCLIST_INJURED;
		}

		public Integer NUMBER_OF_CYCLIST_KILLED;

		public Integer getNUMBER_OF_CYCLIST_KILLED() {
			return this.NUMBER_OF_CYCLIST_KILLED;
		}

		public Integer NUMBER_OF_MOTORIST_INJURED;

		public Integer getNUMBER_OF_MOTORIST_INJURED() {
			return this.NUMBER_OF_MOTORIST_INJURED;
		}

		public Integer NUMBER_OF_MOTORIST_KILLED;

		public Integer getNUMBER_OF_MOTORIST_KILLED() {
			return this.NUMBER_OF_MOTORIST_KILLED;
		}

		public String CONTRIBUTING_FACTOR_VEHICLE_1;

		public String getCONTRIBUTING_FACTOR_VEHICLE_1() {
			return this.CONTRIBUTING_FACTOR_VEHICLE_1;
		}

		public String CONTRIBUTING_FACTOR_VEHICLE_2;

		public String getCONTRIBUTING_FACTOR_VEHICLE_2() {
			return this.CONTRIBUTING_FACTOR_VEHICLE_2;
		}

		public String CONTRIBUTING_FACTOR_VEHICLE_3;

		public String getCONTRIBUTING_FACTOR_VEHICLE_3() {
			return this.CONTRIBUTING_FACTOR_VEHICLE_3;
		}

		public String CONTRIBUTING_FACTOR_VEHICLE_4;

		public String getCONTRIBUTING_FACTOR_VEHICLE_4() {
			return this.CONTRIBUTING_FACTOR_VEHICLE_4;
		}

		public String CONTRIBUTING_FACTOR_VEHICLE_5;

		public String getCONTRIBUTING_FACTOR_VEHICLE_5() {
			return this.CONTRIBUTING_FACTOR_VEHICLE_5;
		}

		public Integer COLLISION_ID;

		public Integer getCOLLISION_ID() {
			return this.COLLISION_ID;
		}

		public String VEHICLE_TYPE_CODE_1;

		public String getVEHICLE_TYPE_CODE_1() {
			return this.VEHICLE_TYPE_CODE_1;
		}

		public String VEHICLE_TYPE_CODE_2;

		public String getVEHICLE_TYPE_CODE_2() {
			return this.VEHICLE_TYPE_CODE_2;
		}

		public String VEHICLE_TYPE_CODE_3;

		public String getVEHICLE_TYPE_CODE_3() {
			return this.VEHICLE_TYPE_CODE_3;
		}

		public String VEHICLE_TYPE_CODE_4;

		public String getVEHICLE_TYPE_CODE_4() {
			return this.VEHICLE_TYPE_CODE_4;
		}

		public String VEHICLE_TYPE_CODE_5;

		public String getVEHICLE_TYPE_CODE_5() {
			return this.VEHICLE_TYPE_CODE_5;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MOTOR_LoadToStgCrash.length) {
					if (length < 1024 && commonByteArray_MOTOR_LoadToStgCrash.length == 0) {
						commonByteArray_MOTOR_LoadToStgCrash = new byte[1024];
					} else {
						commonByteArray_MOTOR_LoadToStgCrash = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MOTOR_LoadToStgCrash, 0, length);
				strReturn = new String(commonByteArray_MOTOR_LoadToStgCrash, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MOTOR_LoadToStgCrash.length) {
					if (length < 1024 && commonByteArray_MOTOR_LoadToStgCrash.length == 0) {
						commonByteArray_MOTOR_LoadToStgCrash = new byte[1024];
					} else {
						commonByteArray_MOTOR_LoadToStgCrash = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MOTOR_LoadToStgCrash, 0, length);
				strReturn = new String(commonByteArray_MOTOR_LoadToStgCrash, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MOTOR_LoadToStgCrash) {

				try {

					int length = 0;

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.BOROUGH = readString(dis);

					this.ZIP_CODE = readString(dis);

					this.LATITUDE = readString(dis);

					this.LONGITUDE = readString(dis);

					this.LOCATION = readString(dis);

					this.ON_STREET_NAME = readString(dis);

					this.CROSS_STREET_NAME = readString(dis);

					this.OFF_STREET_NAME = readString(dis);

					this.NUMBER_OF_PERSONS_INJURED = readInteger(dis);

					this.NUMBER_OF_PERSONS_KILLED = readInteger(dis);

					this.NUMBER_OF_PEDESTRIANS_INJURED = readInteger(dis);

					this.NUMBER_OF_PEDESTRIANS_KILLED = readInteger(dis);

					this.NUMBER_OF_CYCLIST_INJURED = readInteger(dis);

					this.NUMBER_OF_CYCLIST_KILLED = readInteger(dis);

					this.NUMBER_OF_MOTORIST_INJURED = readInteger(dis);

					this.NUMBER_OF_MOTORIST_KILLED = readInteger(dis);

					this.CONTRIBUTING_FACTOR_VEHICLE_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_VEHICLE_2 = readString(dis);

					this.CONTRIBUTING_FACTOR_VEHICLE_3 = readString(dis);

					this.CONTRIBUTING_FACTOR_VEHICLE_4 = readString(dis);

					this.CONTRIBUTING_FACTOR_VEHICLE_5 = readString(dis);

					this.COLLISION_ID = readInteger(dis);

					this.VEHICLE_TYPE_CODE_1 = readString(dis);

					this.VEHICLE_TYPE_CODE_2 = readString(dis);

					this.VEHICLE_TYPE_CODE_3 = readString(dis);

					this.VEHICLE_TYPE_CODE_4 = readString(dis);

					this.VEHICLE_TYPE_CODE_5 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MOTOR_LoadToStgCrash) {

				try {

					int length = 0;

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.BOROUGH = readString(dis);

					this.ZIP_CODE = readString(dis);

					this.LATITUDE = readString(dis);

					this.LONGITUDE = readString(dis);

					this.LOCATION = readString(dis);

					this.ON_STREET_NAME = readString(dis);

					this.CROSS_STREET_NAME = readString(dis);

					this.OFF_STREET_NAME = readString(dis);

					this.NUMBER_OF_PERSONS_INJURED = readInteger(dis);

					this.NUMBER_OF_PERSONS_KILLED = readInteger(dis);

					this.NUMBER_OF_PEDESTRIANS_INJURED = readInteger(dis);

					this.NUMBER_OF_PEDESTRIANS_KILLED = readInteger(dis);

					this.NUMBER_OF_CYCLIST_INJURED = readInteger(dis);

					this.NUMBER_OF_CYCLIST_KILLED = readInteger(dis);

					this.NUMBER_OF_MOTORIST_INJURED = readInteger(dis);

					this.NUMBER_OF_MOTORIST_KILLED = readInteger(dis);

					this.CONTRIBUTING_FACTOR_VEHICLE_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_VEHICLE_2 = readString(dis);

					this.CONTRIBUTING_FACTOR_VEHICLE_3 = readString(dis);

					this.CONTRIBUTING_FACTOR_VEHICLE_4 = readString(dis);

					this.CONTRIBUTING_FACTOR_VEHICLE_5 = readString(dis);

					this.COLLISION_ID = readInteger(dis);

					this.VEHICLE_TYPE_CODE_1 = readString(dis);

					this.VEHICLE_TYPE_CODE_2 = readString(dis);

					this.VEHICLE_TYPE_CODE_3 = readString(dis);

					this.VEHICLE_TYPE_CODE_4 = readString(dis);

					this.VEHICLE_TYPE_CODE_5 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.BOROUGH, dos);

				// String

				writeString(this.ZIP_CODE, dos);

				// String

				writeString(this.LATITUDE, dos);

				// String

				writeString(this.LONGITUDE, dos);

				// String

				writeString(this.LOCATION, dos);

				// String

				writeString(this.ON_STREET_NAME, dos);

				// String

				writeString(this.CROSS_STREET_NAME, dos);

				// String

				writeString(this.OFF_STREET_NAME, dos);

				// Integer

				writeInteger(this.NUMBER_OF_PERSONS_INJURED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_PERSONS_KILLED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_PEDESTRIANS_INJURED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_PEDESTRIANS_KILLED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_CYCLIST_INJURED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_CYCLIST_KILLED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_MOTORIST_INJURED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_MOTORIST_KILLED, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_VEHICLE_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_VEHICLE_2, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_VEHICLE_3, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_VEHICLE_4, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_VEHICLE_5, dos);

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.VEHICLE_TYPE_CODE_1, dos);

				// String

				writeString(this.VEHICLE_TYPE_CODE_2, dos);

				// String

				writeString(this.VEHICLE_TYPE_CODE_3, dos);

				// String

				writeString(this.VEHICLE_TYPE_CODE_4, dos);

				// String

				writeString(this.VEHICLE_TYPE_CODE_5, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.BOROUGH, dos);

				// String

				writeString(this.ZIP_CODE, dos);

				// String

				writeString(this.LATITUDE, dos);

				// String

				writeString(this.LONGITUDE, dos);

				// String

				writeString(this.LOCATION, dos);

				// String

				writeString(this.ON_STREET_NAME, dos);

				// String

				writeString(this.CROSS_STREET_NAME, dos);

				// String

				writeString(this.OFF_STREET_NAME, dos);

				// Integer

				writeInteger(this.NUMBER_OF_PERSONS_INJURED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_PERSONS_KILLED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_PEDESTRIANS_INJURED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_PEDESTRIANS_KILLED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_CYCLIST_INJURED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_CYCLIST_KILLED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_MOTORIST_INJURED, dos);

				// Integer

				writeInteger(this.NUMBER_OF_MOTORIST_KILLED, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_VEHICLE_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_VEHICLE_2, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_VEHICLE_3, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_VEHICLE_4, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_VEHICLE_5, dos);

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.VEHICLE_TYPE_CODE_1, dos);

				// String

				writeString(this.VEHICLE_TYPE_CODE_2, dos);

				// String

				writeString(this.VEHICLE_TYPE_CODE_3, dos);

				// String

				writeString(this.VEHICLE_TYPE_CODE_4, dos);

				// String

				writeString(this.VEHICLE_TYPE_CODE_5, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("CRASH_DATE=" + CRASH_DATE);
			sb.append(",CRASH_TIME=" + CRASH_TIME);
			sb.append(",BOROUGH=" + BOROUGH);
			sb.append(",ZIP_CODE=" + ZIP_CODE);
			sb.append(",LATITUDE=" + LATITUDE);
			sb.append(",LONGITUDE=" + LONGITUDE);
			sb.append(",LOCATION=" + LOCATION);
			sb.append(",ON_STREET_NAME=" + ON_STREET_NAME);
			sb.append(",CROSS_STREET_NAME=" + CROSS_STREET_NAME);
			sb.append(",OFF_STREET_NAME=" + OFF_STREET_NAME);
			sb.append(",NUMBER_OF_PERSONS_INJURED=" + String.valueOf(NUMBER_OF_PERSONS_INJURED));
			sb.append(",NUMBER_OF_PERSONS_KILLED=" + String.valueOf(NUMBER_OF_PERSONS_KILLED));
			sb.append(",NUMBER_OF_PEDESTRIANS_INJURED=" + String.valueOf(NUMBER_OF_PEDESTRIANS_INJURED));
			sb.append(",NUMBER_OF_PEDESTRIANS_KILLED=" + String.valueOf(NUMBER_OF_PEDESTRIANS_KILLED));
			sb.append(",NUMBER_OF_CYCLIST_INJURED=" + String.valueOf(NUMBER_OF_CYCLIST_INJURED));
			sb.append(",NUMBER_OF_CYCLIST_KILLED=" + String.valueOf(NUMBER_OF_CYCLIST_KILLED));
			sb.append(",NUMBER_OF_MOTORIST_INJURED=" + String.valueOf(NUMBER_OF_MOTORIST_INJURED));
			sb.append(",NUMBER_OF_MOTORIST_KILLED=" + String.valueOf(NUMBER_OF_MOTORIST_KILLED));
			sb.append(",CONTRIBUTING_FACTOR_VEHICLE_1=" + CONTRIBUTING_FACTOR_VEHICLE_1);
			sb.append(",CONTRIBUTING_FACTOR_VEHICLE_2=" + CONTRIBUTING_FACTOR_VEHICLE_2);
			sb.append(",CONTRIBUTING_FACTOR_VEHICLE_3=" + CONTRIBUTING_FACTOR_VEHICLE_3);
			sb.append(",CONTRIBUTING_FACTOR_VEHICLE_4=" + CONTRIBUTING_FACTOR_VEHICLE_4);
			sb.append(",CONTRIBUTING_FACTOR_VEHICLE_5=" + CONTRIBUTING_FACTOR_VEHICLE_5);
			sb.append(",COLLISION_ID=" + String.valueOf(COLLISION_ID));
			sb.append(",VEHICLE_TYPE_CODE_1=" + VEHICLE_TYPE_CODE_1);
			sb.append(",VEHICLE_TYPE_CODE_2=" + VEHICLE_TYPE_CODE_2);
			sb.append(",VEHICLE_TYPE_CODE_3=" + VEHICLE_TYPE_CODE_3);
			sb.append(",VEHICLE_TYPE_CODE_4=" + VEHICLE_TYPE_CODE_4);
			sb.append(",VEHICLE_TYPE_CODE_5=" + VEHICLE_TYPE_CODE_5);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (CRASH_DATE == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_DATE);
			}

			sb.append("|");

			if (CRASH_TIME == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_TIME);
			}

			sb.append("|");

			if (BOROUGH == null) {
				sb.append("<null>");
			} else {
				sb.append(BOROUGH);
			}

			sb.append("|");

			if (ZIP_CODE == null) {
				sb.append("<null>");
			} else {
				sb.append(ZIP_CODE);
			}

			sb.append("|");

			if (LATITUDE == null) {
				sb.append("<null>");
			} else {
				sb.append(LATITUDE);
			}

			sb.append("|");

			if (LONGITUDE == null) {
				sb.append("<null>");
			} else {
				sb.append(LONGITUDE);
			}

			sb.append("|");

			if (LOCATION == null) {
				sb.append("<null>");
			} else {
				sb.append(LOCATION);
			}

			sb.append("|");

			if (ON_STREET_NAME == null) {
				sb.append("<null>");
			} else {
				sb.append(ON_STREET_NAME);
			}

			sb.append("|");

			if (CROSS_STREET_NAME == null) {
				sb.append("<null>");
			} else {
				sb.append(CROSS_STREET_NAME);
			}

			sb.append("|");

			if (OFF_STREET_NAME == null) {
				sb.append("<null>");
			} else {
				sb.append(OFF_STREET_NAME);
			}

			sb.append("|");

			if (NUMBER_OF_PERSONS_INJURED == null) {
				sb.append("<null>");
			} else {
				sb.append(NUMBER_OF_PERSONS_INJURED);
			}

			sb.append("|");

			if (NUMBER_OF_PERSONS_KILLED == null) {
				sb.append("<null>");
			} else {
				sb.append(NUMBER_OF_PERSONS_KILLED);
			}

			sb.append("|");

			if (NUMBER_OF_PEDESTRIANS_INJURED == null) {
				sb.append("<null>");
			} else {
				sb.append(NUMBER_OF_PEDESTRIANS_INJURED);
			}

			sb.append("|");

			if (NUMBER_OF_PEDESTRIANS_KILLED == null) {
				sb.append("<null>");
			} else {
				sb.append(NUMBER_OF_PEDESTRIANS_KILLED);
			}

			sb.append("|");

			if (NUMBER_OF_CYCLIST_INJURED == null) {
				sb.append("<null>");
			} else {
				sb.append(NUMBER_OF_CYCLIST_INJURED);
			}

			sb.append("|");

			if (NUMBER_OF_CYCLIST_KILLED == null) {
				sb.append("<null>");
			} else {
				sb.append(NUMBER_OF_CYCLIST_KILLED);
			}

			sb.append("|");

			if (NUMBER_OF_MOTORIST_INJURED == null) {
				sb.append("<null>");
			} else {
				sb.append(NUMBER_OF_MOTORIST_INJURED);
			}

			sb.append("|");

			if (NUMBER_OF_MOTORIST_KILLED == null) {
				sb.append("<null>");
			} else {
				sb.append(NUMBER_OF_MOTORIST_KILLED);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_VEHICLE_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_VEHICLE_1);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_VEHICLE_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_VEHICLE_2);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_VEHICLE_3 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_VEHICLE_3);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_VEHICLE_4 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_VEHICLE_4);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_VEHICLE_5 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_VEHICLE_5);
			}

			sb.append("|");

			if (COLLISION_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(COLLISION_ID);
			}

			sb.append("|");

			if (VEHICLE_TYPE_CODE_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE_CODE_1);
			}

			sb.append("|");

			if (VEHICLE_TYPE_CODE_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE_CODE_2);
			}

			sb.append("|");

			if (VEHICLE_TYPE_CODE_3 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE_CODE_3);
			}

			sb.append("|");

			if (VEHICLE_TYPE_CODE_4 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE_CODE_4);
			}

			sb.append("|");

			if (VEHICLE_TYPE_CODE_5 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE_CODE_5);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tBigQueryInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tBigQueryInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				outStruct out = new outStruct();

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "out");
				}

				int tos_count_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
							log4jParamters_tDBOutput_1.append("Parameters:");
							log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DRIVER" + " = " + "MSSQL_PROP");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("HOST" + " = " + "\"MYWATERCOLOF781\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DBNAME" + " = " + "\"Motor\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USER" + " = " + "\"dongxuejiaonew\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:2FWGIIrgvFwiTigPhf60GMM/L4Vz7XkfSB9JFxEghcIQDmSdkZUx4Y42iA==")
									.substring(0, 4) + "...");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"stg_nyc_mv_collisions_BigQuery\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "DROP_IF_EXISTS_AND_CREATE");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SPECIFY_IDENTITY_FIELD" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ACTIVE_DIR_AUTH" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_1 - " + (log4jParamters_tDBOutput_1));
						}
					}
					new BytesLimit65535_tDBOutput_1().limitLog4jByte();
				}

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rowsToCommitCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;
				String dbschema_tDBOutput_1 = null;
				String tableName_tDBOutput_1 = null;
				boolean whetherReject_tDBOutput_1 = false;

				java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
				long year1_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_1;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_1 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_1 = null;
				String dbUser_tDBOutput_1 = null;
				dbschema_tDBOutput_1 = "";
				String driverClass_tDBOutput_1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_1) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_1);
				String port_tDBOutput_1 = "1433";
				String dbname_tDBOutput_1 = "Motor";
				String url_tDBOutput_1 = "jdbc:sqlserver://" + "MYWATERCOLOF781";
				if (!"".equals(port_tDBOutput_1)) {
					url_tDBOutput_1 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_1)) {
					url_tDBOutput_1 += ";databaseName=" + "Motor";

				}
				url_tDBOutput_1 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_1 = "dongxuejiaonew";

				final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:MSs4tzKlSlneY74VDS3IPx5XZD6GS8KhvqBmmXbhzRxc9GR7kQiquNHVeA==");

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection attempts to '") + (url_tDBOutput_1)
							+ ("' with the username '") + (dbUser_tDBOutput_1) + ("'."));
				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, dbUser_tDBOutput_1,
						dbPwd_tDBOutput_1);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to '") + (url_tDBOutput_1) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);

				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_1.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_1 = 10000;
				int batchSizeCounter_tDBOutput_1 = 0;

				if (dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
					tableName_tDBOutput_1 = "stg_nyc_mv_collisions_BigQuery";
				} else {
					tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "].[" + "stg_nyc_mv_collisions_BigQuery";
				}
				int count_tDBOutput_1 = 0;

				boolean whetherExist_tDBOutput_1 = false;
				try (java.sql.Statement isExistStmt_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
					try {
						isExistStmt_tDBOutput_1.execute("SELECT TOP 1 1 FROM [" + tableName_tDBOutput_1 + "]");
						whetherExist_tDBOutput_1 = true;
					} catch (java.lang.Exception e) {
						globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());
						whetherExist_tDBOutput_1 = false;
					}
				}
				if (whetherExist_tDBOutput_1) {
					try (java.sql.Statement stmtDrop_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Dropping") + (" table '")
									+ ("[" + tableName_tDBOutput_1 + "]") + ("'."));
						stmtDrop_tDBOutput_1.execute("DROP TABLE [" + tableName_tDBOutput_1 + "]");
						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Drop") + (" table '") + ("[" + tableName_tDBOutput_1 + "]")
									+ ("' has succeeded."));
					}
				}
				try (java.sql.Statement stmtCreate_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Creating") + (" table '") + ("[" + tableName_tDBOutput_1 + "]")
								+ ("'."));
					stmtCreate_tDBOutput_1.execute("CREATE TABLE [" + tableName_tDBOutput_1
							+ "]([COLLISION_ID] BIGINT  not null ,[collision_dt] DATETIME ,[collision_day] DATE ,[collision_time] TIME(7)  ,[collision_hour] INT ,[collision_dayoftheweek] INT ,[borough] VARCHAR(40)  ,[zip_code] VARCHAR(40)  ,[off_street_name] VARCHAR(40)  ,[on_street_name] VARCHAR(40)  ,[cross_street_name] VARCHAR(40)  ,[latitude] NUMERIC(24,6)  ,[longitude] NUMERIC(24,6)  ,[location] VARCHAR(256)  ,[contributing_factor_vehicle_1] VARCHAR(256)  ,[contributing_factor_vehicle_2] VARCHAR(256)  ,[contributing_factor_vehicle_3] VARCHAR(256)  ,[contributing_factor_vehicle_4] VARCHAR(256)  ,[contributing_factor_vehicle_5] VARCHAR(256)  ,[number_of_cyclist_injured] INT ,[number_of_cyclist_killed] INT ,[number_of_motorist_injured] INT ,[number_of_motorist_killed] INT ,[number_of_pedestrians_injured] INT ,[number_of_pedestrians_killed] INT ,[number_of_persons_injured] INT ,[number_of_persons_killed] INT ,[vehicle_type_code1] VARCHAR(80)  ,[vehicle_type_code2] VARCHAR(80)  ,[vehicle_type_code_3] VARCHAR(80)  ,[vehicle_type_code_4] VARCHAR(80)  ,[vehicle_type_code_5] VARCHAR(80)  ,[DI_JobID] VARCHAR(20)  ,[DI_CreateDate] DATETIME default '(getdate())' ,primary key([COLLISION_ID]))");
					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Create") + (" table '") + ("[" + tableName_tDBOutput_1 + "]")
								+ ("' has succeeded."));
				}
				String insert_tDBOutput_1 = "INSERT INTO [" + tableName_tDBOutput_1
						+ "] ([COLLISION_ID],[collision_dt],[collision_day],[collision_time],[collision_hour],[collision_dayoftheweek],[borough],[zip_code],[off_street_name],[on_street_name],[cross_street_name],[latitude],[longitude],[location],[contributing_factor_vehicle_1],[contributing_factor_vehicle_2],[contributing_factor_vehicle_3],[contributing_factor_vehicle_4],[contributing_factor_vehicle_5],[number_of_cyclist_injured],[number_of_cyclist_killed],[number_of_motorist_injured],[number_of_motorist_killed],[number_of_pedestrians_injured],[number_of_pedestrians_killed],[number_of_persons_injured],[number_of_persons_killed],[vehicle_type_code1],[vehicle_type_code2],[vehicle_type_code_3],[vehicle_type_code_4],[vehicle_type_code_5],[DI_JobID],[DI_CreateDate]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tMap_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_1 = new StringBuilder();
							log4jParamters_tMap_1.append("Parameters:");
							log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_1 - " + (log4jParamters_tMap_1));
						}
					}
					new BytesLimit65535_tMap_1().limitLog4jByte();
				}

// ###############################
// # Lookup's keys initialization
				int count_row1_tMap_1 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out_tMap_1 = 0;

				outStruct out_tmp = new outStruct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tBigQueryInput_1 begin ] start
				 */

				ok_Hash.put("tBigQueryInput_1", false);
				start_Hash.put("tBigQueryInput_1", System.currentTimeMillis());

				currentComponent = "tBigQueryInput_1";

				int tos_count_tBigQueryInput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tBigQueryInput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tBigQueryInput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tBigQueryInput_1 = new StringBuilder();
							log4jParamters_tBigQueryInput_1.append("Parameters:");
							log4jParamters_tBigQueryInput_1.append("AUTH_MODE" + " = " + "SERVICEACCOUNT");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("SERVICE_ACCOUNT_CREDENTIALS_FILE" + " = "
									+ "\"//Mac/Home/Downloads/json/ornate-compass-364518-20afbcf0d390.json\"");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("PROJECT_ID" + " = " + "\"ornate-compass-364518\"");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("USE_LEGACY_SQL" + " = " + "false");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("QUERY" + " = "
									+ "\"  SELECT   CRASH_DATE,  CRASH_TIME,  BOROUGH,  ZIP_CODE,  LATITUDE,  LONGITUDE,  LOCATION,  ON_STREET_NAME,  CROSS_STREET_NAME,  OFF_STREET_NAME,  NUMBER_OF_PERSONS_INJURED,  NUMBER_OF_PERSONS_KILLED,  NUMBER_OF_PEDESTRIANS_INJURED,  NUMBER_OF_PEDESTRIANS_KILLED,  NUMBER_OF_CYCLIST_INJURED,  NUMBER_OF_CYCLIST_KILLED,  NUMBER_OF_MOTORIST_INJURED,  NUMBER_OF_MOTORIST_KILLED,  CONTRIBUTING_FACTOR_VEHICLE_1,  CONTRIBUTING_FACTOR_VEHICLE_2,  CONTRIBUTING_FACTOR_VEHICLE_3,  CONTRIBUTING_FACTOR_VEHICLE_4,  CONTRIBUTING_FACTOR_VEHICLE_5,  COLLISION_ID,  VEHICLE_TYPE_CODE_1,  VEHICLE_TYPE_CODE_2,  VEHICLE_TYPE_CODE_3,  VEHICLE_TYPE_CODE_4,  VEHICLE_TYPE_CODE_5  FROM ornate-compass-364518.damg7370DB_dxj.Crashes  \"");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("RESULT_SIZE" + " = " + "LARGE");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tBigQueryInput_1.append(" | ");
							log4jParamters_tBigQueryInput_1.append("USE_CUSTOM_TEMPORARY_DATASET" + " = " + "false");
							log4jParamters_tBigQueryInput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tBigQueryInput_1 - " + (log4jParamters_tBigQueryInput_1));
						}
					}
					new BytesLimit65535_tBigQueryInput_1().limitLog4jByte();
				}

				class ServiceAccountBigQueryUtil_tBigQueryInput_1 {
					private com.google.cloud.bigquery.BigQuery bigQuery;
					private boolean useLargeResult;
					private String tempTable;

					public ServiceAccountBigQueryUtil_tBigQueryInput_1() {
						this.useLargeResult = true;
					}

					private com.google.cloud.bigquery.BigQuery buildBigQuery() throws java.io.IOException {
						if (bigQuery != null) {
							return bigQuery;
						}
						com.google.auth.oauth2.GoogleCredentials credentials;
						java.io.File credentialsFile = new java.io.File(
								"//Mac/Home/Downloads/json/ornate-compass-364518-20afbcf0d390.json");
						try (java.io.FileInputStream credentialsStream = new java.io.FileInputStream(credentialsFile)) {
							credentials = com.google.auth.oauth2.ServiceAccountCredentials
									.fromStream(credentialsStream);
						}

						com.google.cloud.bigquery.BigQuery result = com.google.cloud.bigquery.BigQueryOptions
								.newBuilder().setCredentials(credentials).setProjectId("ornate-compass-364518").build()
								.getService();

						return result;
					}

					private com.google.cloud.bigquery.Job buildJob(com.google.cloud.bigquery.BigQuery bigquery,
							com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration,
							com.google.cloud.bigquery.JobId jobId) throws InterruptedException {
						globalMap.put("tBigQueryInput_1_JOBID", jobId.getJob());
						com.google.cloud.bigquery.Job job = bigquery.create(com.google.cloud.bigquery.JobInfo
								.newBuilder(queryConfiguration).setJobId(jobId).build());

						log.info("tBigQueryInput_1 - Sending job " + jobId + " with query: "
								+ "  SELECT   CRASH_DATE,  CRASH_TIME,  BOROUGH,  ZIP_CODE,  LATITUDE,  LONGITUDE,  LOCATION,  ON_STREET_NAME,  CROSS_STREET_NAME,  OFF_STREET_NAME,  NUMBER_OF_PERSONS_INJURED,  NUMBER_OF_PERSONS_KILLED,  NUMBER_OF_PEDESTRIANS_INJURED,  NUMBER_OF_PEDESTRIANS_KILLED,  NUMBER_OF_CYCLIST_INJURED,  NUMBER_OF_CYCLIST_KILLED,  NUMBER_OF_MOTORIST_INJURED,  NUMBER_OF_MOTORIST_KILLED,  CONTRIBUTING_FACTOR_VEHICLE_1,  CONTRIBUTING_FACTOR_VEHICLE_2,  CONTRIBUTING_FACTOR_VEHICLE_3,  CONTRIBUTING_FACTOR_VEHICLE_4,  CONTRIBUTING_FACTOR_VEHICLE_5,  COLLISION_ID,  VEHICLE_TYPE_CODE_1,  VEHICLE_TYPE_CODE_2,  VEHICLE_TYPE_CODE_3,  VEHICLE_TYPE_CODE_4,  VEHICLE_TYPE_CODE_5  FROM ornate-compass-364518.damg7370DB_dxj.Crashes  ");

						job = job.waitFor();

						if (job == null) {
							String message = "tBigQueryInput_1 - Job no longer exists";
							globalMap.put("tBigQueryInput_1_ERROR_MESSAGE", message);
							throw new RuntimeException(message);
						} else if (job.getStatus().getError() != null) {
							com.google.gson.Gson gsonObject = new com.google.gson.Gson();
							globalMap.put("tBigQueryInput_1_STATISTICS", gsonObject.toJson(job.getStatistics()));
							String message = job.getStatus().getError().toString();
							globalMap.put("tBigQueryInput_1_ERROR_MESSAGE", message);
							throw new RuntimeException(message);
						}

						log.info("tBigQueryInput_1 - Job " + jobId + " finished successfully.");

						return job;
					}

					private com.google.cloud.bigquery.Job executeQuerySmallResult(String query, boolean useLegacySql)
							throws java.io.IOException, InterruptedException {
						bigQuery = buildBigQuery();
						com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration = com.google.cloud.bigquery.QueryJobConfiguration
								.newBuilder(query).setUseLegacySql(useLegacySql).build();
						com.google.cloud.bigquery.JobId jobId = com.google.cloud.bigquery.JobId
								.of("ornate-compass-364518", java.util.UUID.randomUUID().toString());
						return buildJob(bigQuery, queryConfiguration, jobId);
					}

					private com.google.cloud.bigquery.Job executeQueryLargeResult(String query, boolean useLegacySql)
							throws java.io.IOException, InterruptedException {
						bigQuery = buildBigQuery();

						com.google.cloud.bigquery.QueryJobConfiguration jobConfDryRun = com.google.cloud.bigquery.QueryJobConfiguration
								.newBuilder(query).setUseLegacySql(useLegacySql).setDryRun(true).build();
						com.google.cloud.bigquery.Job jobDryRun = bigQuery
								.create(com.google.cloud.bigquery.JobInfo.of(jobConfDryRun));

						String queryLocation = jobDryRun.getJobId().getLocation();
						String location = queryLocation == null ? "US" : queryLocation;
						String tempDataset = java.util.UUID.randomUUID().toString().replaceAll("-", "")
								+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt())
								+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt());

						log.info("tBigQueryInput_1 - query location :" + queryLocation);
						log.info("tBigQueryInput_1 - temporary dataset location :" + location);
						log.info("tBigQueryInput_1 - temporary Dataset name : " + tempDataset);

						com.google.cloud.bigquery.DatasetInfo datasetInfo = com.google.cloud.bigquery.DatasetInfo
								.newBuilder(tempDataset).setLocation(location).build();
						com.google.cloud.bigquery.Dataset dataset = bigQuery.create(datasetInfo);

						tempTable = java.util.UUID.randomUUID().toString().replaceAll("-", "")
								+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt())
								+ Integer.toHexString(java.util.concurrent.ThreadLocalRandom.current().nextInt());

						log.info("tBigQueryInput_1 - temporary table name : " + tempTable);

						com.google.cloud.bigquery.QueryJobConfiguration queryConfiguration = com.google.cloud.bigquery.QueryJobConfiguration
								.newBuilder(query).setUseLegacySql(useLegacySql).setDryRun(false)
								.setAllowLargeResults(true)
								.setDestinationTable(com.google.cloud.bigquery.TableId.of(tempDataset, tempTable))
								.build();

						com.google.cloud.bigquery.JobId jobId = com.google.cloud.bigquery.JobId.newBuilder()
								.setProject("ornate-compass-364518").setJob(java.util.UUID.randomUUID().toString())
								.build();

						log.info("tBigQueryInput_1 - job location : " + jobId.getLocation());

						return buildJob(bigQuery, queryConfiguration, jobId);
					}

					public com.google.cloud.bigquery.Job executeQuery(String query, boolean useLegacySql)
							throws Exception {

						com.google.cloud.bigquery.Job job;

						job = executeQueryLargeResult(query, useLegacySql);

						return job;
					}

					public java.util.List<com.google.cloud.bigquery.Job> getChildJobs(String jobId)
							throws java.io.IOException {
						return java.util.Optional
								.ofNullable(buildBigQuery()
										.listJobs(com.google.cloud.bigquery.BigQuery.JobListOption.parentJobId(jobId)))
								.map(com.google.api.gax.paging.Page::getValues)
								.flatMap(iterable -> java.util.Optional
										.ofNullable(java.util.stream.StreamSupport.stream(iterable.spliterator(), false)
												.collect(java.util.stream.Collectors.toList())))
								.orElse(java.util.Collections.emptyList());
					}

					public void cleanup() throws Exception {
						if (useLargeResult) {

							com.google.cloud.bigquery.DatasetId datasetId = com.google.cloud.bigquery.DatasetId
									.of("ornate-compass-364518", "temp_dataset");
							bigQuery.delete(datasetId,
									com.google.cloud.bigquery.BigQuery.DatasetDeleteOption.deleteContents());

						}
					}

				}

				log.info("tBigQueryInput_1 - query "
						+ "  SELECT   CRASH_DATE,  CRASH_TIME,  BOROUGH,  ZIP_CODE,  LATITUDE,  LONGITUDE,  LOCATION,  ON_STREET_NAME,  CROSS_STREET_NAME,  OFF_STREET_NAME,  NUMBER_OF_PERSONS_INJURED,  NUMBER_OF_PERSONS_KILLED,  NUMBER_OF_PEDESTRIANS_INJURED,  NUMBER_OF_PEDESTRIANS_KILLED,  NUMBER_OF_CYCLIST_INJURED,  NUMBER_OF_CYCLIST_KILLED,  NUMBER_OF_MOTORIST_INJURED,  NUMBER_OF_MOTORIST_KILLED,  CONTRIBUTING_FACTOR_VEHICLE_1,  CONTRIBUTING_FACTOR_VEHICLE_2,  CONTRIBUTING_FACTOR_VEHICLE_3,  CONTRIBUTING_FACTOR_VEHICLE_4,  CONTRIBUTING_FACTOR_VEHICLE_5,  COLLISION_ID,  VEHICLE_TYPE_CODE_1,  VEHICLE_TYPE_CODE_2,  VEHICLE_TYPE_CODE_3,  VEHICLE_TYPE_CODE_4,  VEHICLE_TYPE_CODE_5  FROM ornate-compass-364518.damg7370DB_dxj.Crashes  ");

				ServiceAccountBigQueryUtil_tBigQueryInput_1 serviceAccountBigQueryUtil_tBigQueryInput_1 = new ServiceAccountBigQueryUtil_tBigQueryInput_1();

				try {
					com.google.cloud.bigquery.Job job_tBigQueryInput_1 = serviceAccountBigQueryUtil_tBigQueryInput_1
							.executeQuery(
									"  SELECT   CRASH_DATE,  CRASH_TIME,  BOROUGH,  ZIP_CODE,  LATITUDE,  LONGITUDE,  LOCATION,  ON_STREET_NAME,  CROSS_STREET_NAME,  OFF_STREET_NAME,  NUMBER_OF_PERSONS_INJURED,  NUMBER_OF_PERSONS_KILLED,  NUMBER_OF_PEDESTRIANS_INJURED,  NUMBER_OF_PEDESTRIANS_KILLED,  NUMBER_OF_CYCLIST_INJURED,  NUMBER_OF_CYCLIST_KILLED,  NUMBER_OF_MOTORIST_INJURED,  NUMBER_OF_MOTORIST_KILLED,  CONTRIBUTING_FACTOR_VEHICLE_1,  CONTRIBUTING_FACTOR_VEHICLE_2,  CONTRIBUTING_FACTOR_VEHICLE_3,  CONTRIBUTING_FACTOR_VEHICLE_4,  CONTRIBUTING_FACTOR_VEHICLE_5,  COLLISION_ID,  VEHICLE_TYPE_CODE_1,  VEHICLE_TYPE_CODE_2,  VEHICLE_TYPE_CODE_3,  VEHICLE_TYPE_CODE_4,  VEHICLE_TYPE_CODE_5  FROM ornate-compass-364518.damg7370DB_dxj.Crashes  ",
									false);
					log.info("tBigQueryInput_1 - Retrieving records from dataset.");

					com.google.gson.Gson gsonObject_tBigQueryInput_1 = new com.google.gson.Gson();
					globalMap.put("tBigQueryInput_1_STATISTICS",
							gsonObject_tBigQueryInput_1.toJson(job_tBigQueryInput_1.getStatistics()));
					long nb_line_tBigQueryInput_1 = 0;
					java.util.List<String> child_statistics_tBigQueryInput_1 = null;
					java.util.List<com.google.cloud.bigquery.Job> childJobs_tBigQueryInput_1;
					if (job_tBigQueryInput_1.getStatistics().getNumChildJobs() != null) {
						childJobs_tBigQueryInput_1 = serviceAccountBigQueryUtil_tBigQueryInput_1
								.getChildJobs(job_tBigQueryInput_1.getJobId().getJob());
						java.util.Collections.reverse(childJobs_tBigQueryInput_1);
						child_statistics_tBigQueryInput_1 = new java.util.ArrayList<>();
					} else {
						childJobs_tBigQueryInput_1 = java.util.Collections.singletonList(job_tBigQueryInput_1);
					}
					for (com.google.cloud.bigquery.Job job_iterable_tBigQueryInput_1 : childJobs_tBigQueryInput_1) {
						if (child_statistics_tBigQueryInput_1 != null) {
							child_statistics_tBigQueryInput_1.add(
									gsonObject_tBigQueryInput_1.toJson(job_iterable_tBigQueryInput_1.getStatistics()));
						}
						if (job_iterable_tBigQueryInput_1.getStatus().getError() != null) {
							globalMap.put("tBigQueryInput_1_ERROR_MESSAGE",
									job_iterable_tBigQueryInput_1.getStatus().getError().toString());
							String message_tBigQueryInput_1 = "tBigQueryInput_1 - "
									+ job_iterable_tBigQueryInput_1.getStatus().getError().toString();
							log.error(message_tBigQueryInput_1);
							continue;
						}

						com.google.cloud.bigquery.TableResult result_tBigQueryInput_1 = job_iterable_tBigQueryInput_1
								.getQueryResults();
						// Dynamic start

						// Dynamic end

						for (com.google.cloud.bigquery.FieldValueList field_tBigQueryInput_1 : result_tBigQueryInput_1
								.iterateAll()) {
							Object value_tBigQueryInput_1;
							nb_line_tBigQueryInput_1++;

							int fieldsCount_tBigQueryInput_1 = field_tBigQueryInput_1.size();
							int column_index_tBigQueryInput_1 = 0;

							column_index_tBigQueryInput_1 = 0;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.CRASH_DATE = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.CRASH_DATE = value_tBigQueryInput_1.toString();

								} else {
									row1.CRASH_DATE = null;
								}
							}

							column_index_tBigQueryInput_1 = 1;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.CRASH_TIME = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.CRASH_TIME = value_tBigQueryInput_1.toString();

								} else {
									row1.CRASH_TIME = null;
								}
							}

							column_index_tBigQueryInput_1 = 2;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.BOROUGH = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.BOROUGH = value_tBigQueryInput_1.toString();

								} else {
									row1.BOROUGH = null;
								}
							}

							column_index_tBigQueryInput_1 = 3;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.ZIP_CODE = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.ZIP_CODE = value_tBigQueryInput_1.toString();

								} else {
									row1.ZIP_CODE = null;
								}
							}

							column_index_tBigQueryInput_1 = 4;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.LATITUDE = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.LATITUDE = value_tBigQueryInput_1.toString();

								} else {
									row1.LATITUDE = null;
								}
							}

							column_index_tBigQueryInput_1 = 5;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.LONGITUDE = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.LONGITUDE = value_tBigQueryInput_1.toString();

								} else {
									row1.LONGITUDE = null;
								}
							}

							column_index_tBigQueryInput_1 = 6;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.LOCATION = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.LOCATION = value_tBigQueryInput_1.toString();

								} else {
									row1.LOCATION = null;
								}
							}

							column_index_tBigQueryInput_1 = 7;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.ON_STREET_NAME = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.ON_STREET_NAME = value_tBigQueryInput_1.toString();

								} else {
									row1.ON_STREET_NAME = null;
								}
							}

							column_index_tBigQueryInput_1 = 8;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.CROSS_STREET_NAME = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.CROSS_STREET_NAME = value_tBigQueryInput_1.toString();

								} else {
									row1.CROSS_STREET_NAME = null;
								}
							}

							column_index_tBigQueryInput_1 = 9;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.OFF_STREET_NAME = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.OFF_STREET_NAME = value_tBigQueryInput_1.toString();

								} else {
									row1.OFF_STREET_NAME = null;
								}
							}

							column_index_tBigQueryInput_1 = 10;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.NUMBER_OF_PERSONS_INJURED = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.NUMBER_OF_PERSONS_INJURED = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.NUMBER_OF_PERSONS_INJURED = null;
								}
							}

							column_index_tBigQueryInput_1 = 11;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.NUMBER_OF_PERSONS_KILLED = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.NUMBER_OF_PERSONS_KILLED = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.NUMBER_OF_PERSONS_KILLED = null;
								}
							}

							column_index_tBigQueryInput_1 = 12;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.NUMBER_OF_PEDESTRIANS_INJURED = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.NUMBER_OF_PEDESTRIANS_INJURED = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.NUMBER_OF_PEDESTRIANS_INJURED = null;
								}
							}

							column_index_tBigQueryInput_1 = 13;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.NUMBER_OF_PEDESTRIANS_KILLED = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.NUMBER_OF_PEDESTRIANS_KILLED = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.NUMBER_OF_PEDESTRIANS_KILLED = null;
								}
							}

							column_index_tBigQueryInput_1 = 14;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.NUMBER_OF_CYCLIST_INJURED = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.NUMBER_OF_CYCLIST_INJURED = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.NUMBER_OF_CYCLIST_INJURED = null;
								}
							}

							column_index_tBigQueryInput_1 = 15;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.NUMBER_OF_CYCLIST_KILLED = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.NUMBER_OF_CYCLIST_KILLED = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.NUMBER_OF_CYCLIST_KILLED = null;
								}
							}

							column_index_tBigQueryInput_1 = 16;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.NUMBER_OF_MOTORIST_INJURED = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.NUMBER_OF_MOTORIST_INJURED = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.NUMBER_OF_MOTORIST_INJURED = null;
								}
							}

							column_index_tBigQueryInput_1 = 17;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.NUMBER_OF_MOTORIST_KILLED = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.NUMBER_OF_MOTORIST_KILLED = ParserUtils
											.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.NUMBER_OF_MOTORIST_KILLED = null;
								}
							}

							column_index_tBigQueryInput_1 = 18;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.CONTRIBUTING_FACTOR_VEHICLE_1 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.CONTRIBUTING_FACTOR_VEHICLE_1 = value_tBigQueryInput_1.toString();

								} else {
									row1.CONTRIBUTING_FACTOR_VEHICLE_1 = null;
								}
							}

							column_index_tBigQueryInput_1 = 19;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.CONTRIBUTING_FACTOR_VEHICLE_2 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.CONTRIBUTING_FACTOR_VEHICLE_2 = value_tBigQueryInput_1.toString();

								} else {
									row1.CONTRIBUTING_FACTOR_VEHICLE_2 = null;
								}
							}

							column_index_tBigQueryInput_1 = 20;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.CONTRIBUTING_FACTOR_VEHICLE_3 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.CONTRIBUTING_FACTOR_VEHICLE_3 = value_tBigQueryInput_1.toString();

								} else {
									row1.CONTRIBUTING_FACTOR_VEHICLE_3 = null;
								}
							}

							column_index_tBigQueryInput_1 = 21;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.CONTRIBUTING_FACTOR_VEHICLE_4 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.CONTRIBUTING_FACTOR_VEHICLE_4 = value_tBigQueryInput_1.toString();

								} else {
									row1.CONTRIBUTING_FACTOR_VEHICLE_4 = null;
								}
							}

							column_index_tBigQueryInput_1 = 22;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.CONTRIBUTING_FACTOR_VEHICLE_5 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.CONTRIBUTING_FACTOR_VEHICLE_5 = value_tBigQueryInput_1.toString();

								} else {
									row1.CONTRIBUTING_FACTOR_VEHICLE_5 = null;
								}
							}

							column_index_tBigQueryInput_1 = 23;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.COLLISION_ID = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.COLLISION_ID = ParserUtils.parseTo_Integer(value_tBigQueryInput_1.toString());

								} else {
									row1.COLLISION_ID = null;
								}
							}

							column_index_tBigQueryInput_1 = 24;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.VEHICLE_TYPE_CODE_1 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.VEHICLE_TYPE_CODE_1 = value_tBigQueryInput_1.toString();

								} else {
									row1.VEHICLE_TYPE_CODE_1 = null;
								}
							}

							column_index_tBigQueryInput_1 = 25;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.VEHICLE_TYPE_CODE_2 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.VEHICLE_TYPE_CODE_2 = value_tBigQueryInput_1.toString();

								} else {
									row1.VEHICLE_TYPE_CODE_2 = null;
								}
							}

							column_index_tBigQueryInput_1 = 26;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.VEHICLE_TYPE_CODE_3 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.VEHICLE_TYPE_CODE_3 = value_tBigQueryInput_1.toString();

								} else {
									row1.VEHICLE_TYPE_CODE_3 = null;
								}
							}

							column_index_tBigQueryInput_1 = 27;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.VEHICLE_TYPE_CODE_4 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.VEHICLE_TYPE_CODE_4 = value_tBigQueryInput_1.toString();

								} else {
									row1.VEHICLE_TYPE_CODE_4 = null;
								}
							}

							column_index_tBigQueryInput_1 = 28;

							if (fieldsCount_tBigQueryInput_1 <= column_index_tBigQueryInput_1) {
								row1.VEHICLE_TYPE_CODE_5 = null;
							} else {

								value_tBigQueryInput_1 = field_tBigQueryInput_1.get(column_index_tBigQueryInput_1)
										.getValue();

								if (com.google.api.client.util.Data.isNull(value_tBigQueryInput_1))
									value_tBigQueryInput_1 = null;

								if (value_tBigQueryInput_1 != null) {

									row1.VEHICLE_TYPE_CODE_5 = value_tBigQueryInput_1.toString();

								} else {
									row1.VEHICLE_TYPE_CODE_5 = null;
								}
							}

							log.debug("tBigQueryInput_1 - Retrieving the record " + (nb_line_tBigQueryInput_1) + ".");

							/**
							 * [tBigQueryInput_1 begin ] stop
							 */

							/**
							 * [tBigQueryInput_1 main ] start
							 */

							currentComponent = "tBigQueryInput_1";

							tos_count_tBigQueryInput_1++;

							/**
							 * [tBigQueryInput_1 main ] stop
							 */

							/**
							 * [tBigQueryInput_1 process_data_begin ] start
							 */

							currentComponent = "tBigQueryInput_1";

							/**
							 * [tBigQueryInput_1 process_data_begin ] stop
							 */

							/**
							 * [tMap_1 main ] start
							 */

							currentComponent = "tMap_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row1"

								);
							}

							if (log.isTraceEnabled()) {
								log.trace("row1 - " + (row1 == null ? "" : row1.toLogString()));
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_1 = false;
							boolean mainRowRejected_tMap_1 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
								// ###############################
								// # Output tables

								out = null;

// # Output table : 'out'
								count_out_tMap_1++;

								out_tmp.COLLISION_ID = row1.COLLISION_ID;
								out_tmp.collision_dt = null;
								out_tmp.collision_day = null;
								out_tmp.collision_time = null;
								out_tmp.collision_hour = null;
								out_tmp.collision_dayoftheweek = null;
								out_tmp.borough = row1.BOROUGH;
								out_tmp.zip_code = row1.ZIP_CODE;
								out_tmp.off_street_name = row1.OFF_STREET_NAME;
								out_tmp.on_street_name = row1.ON_STREET_NAME;
								out_tmp.cross_street_name = row1.CROSS_STREET_NAME;
								out_tmp.latitude = row1.LATITUDE;
								out_tmp.longitude = row1.LONGITUDE;
								out_tmp.location = row1.LOCATION;
								out_tmp.contributing_factor_vehicle_1 = row1.CONTRIBUTING_FACTOR_VEHICLE_1;
								out_tmp.contributing_factor_vehicle_2 = row1.CONTRIBUTING_FACTOR_VEHICLE_2;
								out_tmp.contributing_factor_vehicle_3 = row1.CONTRIBUTING_FACTOR_VEHICLE_3;
								out_tmp.contributing_factor_vehicle_4 = row1.CONTRIBUTING_FACTOR_VEHICLE_4;
								out_tmp.contributing_factor_vehicle_5 = row1.CONTRIBUTING_FACTOR_VEHICLE_5;
								out_tmp.number_of_cyclist_injured = row1.NUMBER_OF_CYCLIST_INJURED;
								out_tmp.number_of_cyclist_killed = row1.NUMBER_OF_CYCLIST_KILLED;
								out_tmp.number_of_motorist_injured = row1.NUMBER_OF_MOTORIST_INJURED;
								out_tmp.number_of_motorist_killed = row1.NUMBER_OF_MOTORIST_KILLED;
								out_tmp.number_of_pedestrians_injured = row1.NUMBER_OF_PEDESTRIANS_INJURED;
								out_tmp.number_of_pedestrians_killed = row1.NUMBER_OF_PEDESTRIANS_KILLED;
								out_tmp.number_of_persons_injured = row1.NUMBER_OF_PERSONS_INJURED;
								out_tmp.number_of_persons_killed = row1.NUMBER_OF_PERSONS_KILLED;
								out_tmp.vehicle_type_code1 = null;
								out_tmp.vehicle_type_code2 = null;
								out_tmp.vehicle_type_code_3 = row1.VEHICLE_TYPE_CODE_3;
								out_tmp.vehicle_type_code_4 = row1.VEHICLE_TYPE_CODE_4;
								out_tmp.vehicle_type_code_5 = row1.VEHICLE_TYPE_CODE_5;
								out_tmp.DI_JobID = "LoadToStgCrash";
								out_tmp.DI_CreateDate = TalendDate.getCurrentDate();
								out = out_tmp;
								log.debug("tMap_1 - Outputting the record " + count_out_tMap_1
										+ " of the output table 'out'.");

// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_1 = false;

							tos_count_tMap_1++;

							/**
							 * [tMap_1 main ] stop
							 */

							/**
							 * [tMap_1 process_data_begin ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_begin ] stop
							 */
// Start of branch "out"
							if (out != null) {

								/**
								 * [tDBOutput_1 main ] start
								 */

								currentComponent = "tDBOutput_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "out"

									);
								}

								if (log.isTraceEnabled()) {
									log.trace("out - " + (out == null ? "" : out.toLogString()));
								}

								whetherReject_tDBOutput_1 = false;
								pstmt_tDBOutput_1.setLong(1, out.COLLISION_ID);

								if (out.collision_dt != null) {
									pstmt_tDBOutput_1.setTimestamp(2,
											new java.sql.Timestamp(out.collision_dt.getTime()));
								} else {
									pstmt_tDBOutput_1.setNull(2, java.sql.Types.TIMESTAMP);
								}

								if (out.collision_day != null) {
									pstmt_tDBOutput_1.setTimestamp(3,
											new java.sql.Timestamp(out.collision_day.getTime()));
								} else {
									pstmt_tDBOutput_1.setNull(3, java.sql.Types.TIMESTAMP);
								}

								if (out.collision_time != null) {
									pstmt_tDBOutput_1.setString(4,
											out.collision_time instanceof java.util.Date
													? new java.text.SimpleDateFormat("HH:mm:ss")
															.format(out.collision_time)
													: out.collision_time.toString());
								} else {
									pstmt_tDBOutput_1.setNull(4, java.sql.Types.TIME);
								}

								if (out.collision_hour == null) {
									pstmt_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_1.setInt(5, out.collision_hour);
								}

								if (out.collision_dayoftheweek == null) {
									pstmt_tDBOutput_1.setNull(6, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_1.setInt(6, out.collision_dayoftheweek);
								}

								if (out.borough == null) {
									pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(7, out.borough);
								}

								if (out.zip_code == null) {
									pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(8, out.zip_code);
								}

								if (out.off_street_name == null) {
									pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(9, out.off_street_name);
								}

								if (out.on_street_name == null) {
									pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(10, out.on_street_name);
								}

								if (out.cross_street_name == null) {
									pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(11, out.cross_street_name);
								}

								if (out.latitude == null) {
									pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(12, out.latitude);
								}

								if (out.longitude == null) {
									pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(13, out.longitude);
								}

								if (out.location == null) {
									pstmt_tDBOutput_1.setNull(14, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(14, out.location);
								}

								if (out.contributing_factor_vehicle_1 == null) {
									pstmt_tDBOutput_1.setNull(15, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(15, out.contributing_factor_vehicle_1);
								}

								if (out.contributing_factor_vehicle_2 == null) {
									pstmt_tDBOutput_1.setNull(16, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(16, out.contributing_factor_vehicle_2);
								}

								if (out.contributing_factor_vehicle_3 == null) {
									pstmt_tDBOutput_1.setNull(17, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(17, out.contributing_factor_vehicle_3);
								}

								if (out.contributing_factor_vehicle_4 == null) {
									pstmt_tDBOutput_1.setNull(18, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(18, out.contributing_factor_vehicle_4);
								}

								if (out.contributing_factor_vehicle_5 == null) {
									pstmt_tDBOutput_1.setNull(19, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(19, out.contributing_factor_vehicle_5);
								}

								if (out.number_of_cyclist_injured == null) {
									pstmt_tDBOutput_1.setNull(20, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_1.setInt(20, out.number_of_cyclist_injured);
								}

								if (out.number_of_cyclist_killed == null) {
									pstmt_tDBOutput_1.setNull(21, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_1.setInt(21, out.number_of_cyclist_killed);
								}

								if (out.number_of_motorist_injured == null) {
									pstmt_tDBOutput_1.setNull(22, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_1.setInt(22, out.number_of_motorist_injured);
								}

								if (out.number_of_motorist_killed == null) {
									pstmt_tDBOutput_1.setNull(23, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_1.setInt(23, out.number_of_motorist_killed);
								}

								if (out.number_of_pedestrians_injured == null) {
									pstmt_tDBOutput_1.setNull(24, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_1.setInt(24, out.number_of_pedestrians_injured);
								}

								if (out.number_of_pedestrians_killed == null) {
									pstmt_tDBOutput_1.setNull(25, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_1.setInt(25, out.number_of_pedestrians_killed);
								}

								if (out.number_of_persons_injured == null) {
									pstmt_tDBOutput_1.setNull(26, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_1.setInt(26, out.number_of_persons_injured);
								}

								if (out.number_of_persons_killed == null) {
									pstmt_tDBOutput_1.setNull(27, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_1.setInt(27, out.number_of_persons_killed);
								}

								if (out.vehicle_type_code1 == null) {
									pstmt_tDBOutput_1.setNull(28, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(28, out.vehicle_type_code1);
								}

								if (out.vehicle_type_code2 == null) {
									pstmt_tDBOutput_1.setNull(29, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(29, out.vehicle_type_code2);
								}

								if (out.vehicle_type_code_3 == null) {
									pstmt_tDBOutput_1.setNull(30, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(30, out.vehicle_type_code_3);
								}

								if (out.vehicle_type_code_4 == null) {
									pstmt_tDBOutput_1.setNull(31, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(31, out.vehicle_type_code_4);
								}

								if (out.vehicle_type_code_5 == null) {
									pstmt_tDBOutput_1.setNull(32, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(32, out.vehicle_type_code_5);
								}

								if (out.DI_JobID == null) {
									pstmt_tDBOutput_1.setNull(33, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(33, out.DI_JobID);
								}

								if (out.DI_CreateDate != null) {
									pstmt_tDBOutput_1.setTimestamp(34,
											new java.sql.Timestamp(out.DI_CreateDate.getTime()));
								} else {
									pstmt_tDBOutput_1.setNull(34, java.sql.Types.TIMESTAMP);
								}

								pstmt_tDBOutput_1.addBatch();
								nb_line_tDBOutput_1++;

								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Adding the record ") + (nb_line_tDBOutput_1)
											+ (" to the ") + ("INSERT") + (" batch."));
								batchSizeCounter_tDBOutput_1++;

								////////// batch execute by batch size///////
								class LimitBytesHelper_tDBOutput_1 {
									public int limitBytePart1(int counter, java.sql.PreparedStatement pstmt_tDBOutput_1)
											throws Exception {
										try {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT")
														+ (" batch."));
											for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
												if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
													break;
												}
												counter += countEach_tDBOutput_1;
											}

											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
														+ (" batch execution has succeeded."));
										} catch (java.sql.BatchUpdateException e) {
											globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

											int countSum_tDBOutput_1 = 0;
											for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
												counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
											}

											log.error("tDBOutput_1 - " + (e.getMessage()));
											System.err.println(e.getMessage());

										}
										return counter;
									}

									public int limitBytePart2(int counter, java.sql.PreparedStatement pstmt_tDBOutput_1)
											throws Exception {
										try {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT")
														+ (" batch."));
											for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
												if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
													break;
												}
												counter += countEach_tDBOutput_1;
											}

											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
														+ (" batch execution has succeeded."));
										} catch (java.sql.BatchUpdateException e) {
											globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

											for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
												counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
											}

											log.error("tDBOutput_1 - " + (e.getMessage()));
											System.err.println(e.getMessage());

										}
										return counter;
									}
								}
								if ((batchSize_tDBOutput_1 > 0)
										&& (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {

									insertedCount_tDBOutput_1 = new LimitBytesHelper_tDBOutput_1()
											.limitBytePart1(insertedCount_tDBOutput_1, pstmt_tDBOutput_1);
									rowsToCommitCount_tDBOutput_1 = insertedCount_tDBOutput_1;

									batchSizeCounter_tDBOutput_1 = 0;
								}

								//////////// commit every////////////

								commitCounter_tDBOutput_1++;
								if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
									if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {

										insertedCount_tDBOutput_1 = new LimitBytesHelper_tDBOutput_1()
												.limitBytePart1(insertedCount_tDBOutput_1, pstmt_tDBOutput_1);

										batchSizeCounter_tDBOutput_1 = 0;
									}
									if (rowsToCommitCount_tDBOutput_1 != 0) {

										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
													+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
									}
									conn_tDBOutput_1.commit();
									if (rowsToCommitCount_tDBOutput_1 != 0) {

										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
										rowsToCommitCount_tDBOutput_1 = 0;
									}
									commitCounter_tDBOutput_1 = 0;
								}

								tos_count_tDBOutput_1++;

								/**
								 * [tDBOutput_1 main ] stop
								 */

								/**
								 * [tDBOutput_1 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_1";

								/**
								 * [tDBOutput_1 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_1 process_data_end ] start
								 */

								currentComponent = "tDBOutput_1";

								/**
								 * [tDBOutput_1 process_data_end ] stop
								 */

							} // End of branch "out"

							/**
							 * [tMap_1 process_data_end ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_end ] stop
							 */

							/**
							 * [tBigQueryInput_1 process_data_end ] start
							 */

							currentComponent = "tBigQueryInput_1";

							/**
							 * [tBigQueryInput_1 process_data_end ] stop
							 */

							/**
							 * [tBigQueryInput_1 end ] start
							 */

							currentComponent = "tBigQueryInput_1";

						}
						if (child_statistics_tBigQueryInput_1 != null) {
							globalMap.put("tBigQueryInput_1_STATISTICS_CHILD",
									child_statistics_tBigQueryInput_1.stream().collect(
											java.util.stream.Collectors.joining(",", "{\"statistics\": [", "]}")));
						}
						// }
						log.debug("tBigQueryInput_1 - Retrieved records count: " + nb_line_tBigQueryInput_1 + " .");

					}
				} catch (Exception e_tBigQueryInput_1) {
					String message_tBigQueryInput_1 = e_tBigQueryInput_1.getMessage();
					log.error(message_tBigQueryInput_1);
					globalMap.put("tBigQueryInput_1_ERROR_MESSAGE", message_tBigQueryInput_1);
					throw e_tBigQueryInput_1;
				} finally {
					serviceAccountBigQueryUtil_tBigQueryInput_1.cleanup();
				}

				if (log.isDebugEnabled())
					log.debug("tBigQueryInput_1 - " + ("Done."));

				ok_Hash.put("tBigQueryInput_1", true);
				end_Hash.put("tBigQueryInput_1", System.currentTimeMillis());

				/**
				 * [tBigQueryInput_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'out': " + count_out_tMap_1 + ".");

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Done."));

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					int countSum_tDBOutput_1 = 0;
					if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
							if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
								break;
							}
							countSum_tDBOutput_1 += countEach_tDBOutput_1;
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_1 = 0;
					for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					log.error("tDBOutput_1 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_1 != null) {

					pstmt_tDBOutput_1.close();
					resourceMap.remove("pstmt_tDBOutput_1");

				}
				resourceMap.put("statementClosed_tDBOutput_1", true);
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
				}
				conn_tDBOutput_1.commit();
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_1 = 0;
				}
				commitCounter_tDBOutput_1 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
				conn_tDBOutput_1.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_1)
							+ (" record(s)."));

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "out");
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Done."));

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tBigQueryInput_1 finally ] start
				 */

				currentComponent = "tBigQueryInput_1";

				/**
				 * [tBigQueryInput_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
						if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_1")) != null) {
							pstmtToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_1")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_1.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								log.error("tDBOutput_1 - " + (errorMessage_tDBOutput_1));
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tBigQueryInput_1_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final LoadToStgCrash LoadToStgCrashClass = new LoadToStgCrash();

		int exitCode = LoadToStgCrashClass.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'LoadToStgCrash' - Done.");
		}

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (!"".equals(log4jLevel)) {

			if ("trace".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.OFF);
			}
			org.apache.logging.log4j.core.config.Configurator
					.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());

		}
		log.info("TalendJob: 'LoadToStgCrash' - Start.");

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = LoadToStgCrash.class.getClassLoader()
					.getResourceAsStream("motor/loadtostgcrash_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = LoadToStgCrash.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tBigQueryInput_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tBigQueryInput_1) {
			globalMap.put("tBigQueryInput_1_SUBPROCESS_STATE", -1);

			e_tBigQueryInput_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println(
					(endUsedMemory - startUsedMemory) + " bytes memory increase when running : LoadToStgCrash");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 160996 characters generated by Talend Real-time Big Data Platform on the
 * November 21, 2022 at 10:51:38 PM EST
 ************************************************************************************************/