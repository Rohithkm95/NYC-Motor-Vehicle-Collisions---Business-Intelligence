
package motor.loadtostgvehicle_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: LoadToStgVehicle Purpose: <br>
 * Description: <br>
 * 
 * @author dong.xuej@northeastern.edu
 * @version 8.0.1.20211109_1610
 * @status
 */
public class LoadToStgVehicle implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "LoadToStgVehicle.log");
	}

	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager
			.getLogger(LoadToStgVehicle.class);

	protected static void logIgnoredError(String message, Throwable cause) {
		log.error(message, cause);

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "LoadToStgVehicle";
	private final String projectName = "MOTOR";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					LoadToStgVehicle.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(LoadToStgVehicle.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tFileInputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_2_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_MOTOR_LoadToStgVehicle = new byte[0];
		static byte[] commonByteArray_MOTOR_LoadToStgVehicle = new byte[0];

		public Integer UNIQUE_ID;

		public Integer getUNIQUE_ID() {
			return this.UNIQUE_ID;
		}

		public Integer COLLISION_ID;

		public Integer getCOLLISION_ID() {
			return this.COLLISION_ID;
		}

		public String CRASH_DATE;

		public String getCRASH_DATE() {
			return this.CRASH_DATE;
		}

		public String CRASH_TIME;

		public String getCRASH_TIME() {
			return this.CRASH_TIME;
		}

		public String VEHICLE_ID;

		public String getVEHICLE_ID() {
			return this.VEHICLE_ID;
		}

		public String STATE_REGISTRATION;

		public String getSTATE_REGISTRATION() {
			return this.STATE_REGISTRATION;
		}

		public String VEHICLE_TYPE;

		public String getVEHICLE_TYPE() {
			return this.VEHICLE_TYPE;
		}

		public String VEHICLE_MAKE;

		public String getVEHICLE_MAKE() {
			return this.VEHICLE_MAKE;
		}

		public String VEHICLE_MODEL;

		public String getVEHICLE_MODEL() {
			return this.VEHICLE_MODEL;
		}

		public String VEHICLE_YEAR;

		public String getVEHICLE_YEAR() {
			return this.VEHICLE_YEAR;
		}

		public String TRAVEL_DIRECTION;

		public String getTRAVEL_DIRECTION() {
			return this.TRAVEL_DIRECTION;
		}

		public String VEHICLE_OCCUPANTS;

		public String getVEHICLE_OCCUPANTS() {
			return this.VEHICLE_OCCUPANTS;
		}

		public String DRIVER_SEX;

		public String getDRIVER_SEX() {
			return this.DRIVER_SEX;
		}

		public String DRIVER_LICENSE_STATUS;

		public String getDRIVER_LICENSE_STATUS() {
			return this.DRIVER_LICENSE_STATUS;
		}

		public String DRIVER_LICENSE_JURISDICTION;

		public String getDRIVER_LICENSE_JURISDICTION() {
			return this.DRIVER_LICENSE_JURISDICTION;
		}

		public String PRE_CRASH;

		public String getPRE_CRASH() {
			return this.PRE_CRASH;
		}

		public String POINT_OF_IMPACT;

		public String getPOINT_OF_IMPACT() {
			return this.POINT_OF_IMPACT;
		}

		public String VEHICLE_DAMAGE;

		public String getVEHICLE_DAMAGE() {
			return this.VEHICLE_DAMAGE;
		}

		public String VEHICLE_DAMAGE_1;

		public String getVEHICLE_DAMAGE_1() {
			return this.VEHICLE_DAMAGE_1;
		}

		public String VEHICLE_DAMAGE_2;

		public String getVEHICLE_DAMAGE_2() {
			return this.VEHICLE_DAMAGE_2;
		}

		public String VEHICLE_DAMAGE_3;

		public String getVEHICLE_DAMAGE_3() {
			return this.VEHICLE_DAMAGE_3;
		}

		public String PUBLIC_PROPERTY_DAMAGE;

		public String getPUBLIC_PROPERTY_DAMAGE() {
			return this.PUBLIC_PROPERTY_DAMAGE;
		}

		public String PUBLIC_PROPERTY_DAMAGE_TYPE;

		public String getPUBLIC_PROPERTY_DAMAGE_TYPE() {
			return this.PUBLIC_PROPERTY_DAMAGE_TYPE;
		}

		public String CONTRIBUTING_FACTOR_1;

		public String getCONTRIBUTING_FACTOR_1() {
			return this.CONTRIBUTING_FACTOR_1;
		}

		public String CONTRIBUTING_FACTOR_2;

		public String getCONTRIBUTING_FACTOR_2() {
			return this.CONTRIBUTING_FACTOR_2;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MOTOR_LoadToStgVehicle.length) {
					if (length < 1024 && commonByteArray_MOTOR_LoadToStgVehicle.length == 0) {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[1024];
					} else {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MOTOR_LoadToStgVehicle, 0, length);
				strReturn = new String(commonByteArray_MOTOR_LoadToStgVehicle, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MOTOR_LoadToStgVehicle.length) {
					if (length < 1024 && commonByteArray_MOTOR_LoadToStgVehicle.length == 0) {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[1024];
					} else {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MOTOR_LoadToStgVehicle, 0, length);
				strReturn = new String(commonByteArray_MOTOR_LoadToStgVehicle, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MOTOR_LoadToStgVehicle) {

				try {

					int length = 0;

					this.UNIQUE_ID = readInteger(dis);

					this.COLLISION_ID = readInteger(dis);

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.VEHICLE_ID = readString(dis);

					this.STATE_REGISTRATION = readString(dis);

					this.VEHICLE_TYPE = readString(dis);

					this.VEHICLE_MAKE = readString(dis);

					this.VEHICLE_MODEL = readString(dis);

					this.VEHICLE_YEAR = readString(dis);

					this.TRAVEL_DIRECTION = readString(dis);

					this.VEHICLE_OCCUPANTS = readString(dis);

					this.DRIVER_SEX = readString(dis);

					this.DRIVER_LICENSE_STATUS = readString(dis);

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

					this.PRE_CRASH = readString(dis);

					this.POINT_OF_IMPACT = readString(dis);

					this.VEHICLE_DAMAGE = readString(dis);

					this.VEHICLE_DAMAGE_1 = readString(dis);

					this.VEHICLE_DAMAGE_2 = readString(dis);

					this.VEHICLE_DAMAGE_3 = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE_TYPE = readString(dis);

					this.CONTRIBUTING_FACTOR_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_2 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MOTOR_LoadToStgVehicle) {

				try {

					int length = 0;

					this.UNIQUE_ID = readInteger(dis);

					this.COLLISION_ID = readInteger(dis);

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.VEHICLE_ID = readString(dis);

					this.STATE_REGISTRATION = readString(dis);

					this.VEHICLE_TYPE = readString(dis);

					this.VEHICLE_MAKE = readString(dis);

					this.VEHICLE_MODEL = readString(dis);

					this.VEHICLE_YEAR = readString(dis);

					this.TRAVEL_DIRECTION = readString(dis);

					this.VEHICLE_OCCUPANTS = readString(dis);

					this.DRIVER_SEX = readString(dis);

					this.DRIVER_LICENSE_STATUS = readString(dis);

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

					this.PRE_CRASH = readString(dis);

					this.POINT_OF_IMPACT = readString(dis);

					this.VEHICLE_DAMAGE = readString(dis);

					this.VEHICLE_DAMAGE_1 = readString(dis);

					this.VEHICLE_DAMAGE_2 = readString(dis);

					this.VEHICLE_DAMAGE_3 = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE_TYPE = readString(dis);

					this.CONTRIBUTING_FACTOR_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_2 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.UNIQUE_ID, dos);

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.VEHICLE_ID, dos);

				// String

				writeString(this.STATE_REGISTRATION, dos);

				// String

				writeString(this.VEHICLE_TYPE, dos);

				// String

				writeString(this.VEHICLE_MAKE, dos);

				// String

				writeString(this.VEHICLE_MODEL, dos);

				// String

				writeString(this.VEHICLE_YEAR, dos);

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

				// String

				writeString(this.VEHICLE_OCCUPANTS, dos);

				// String

				writeString(this.DRIVER_SEX, dos);

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

				// String

				writeString(this.PRE_CRASH, dos);

				// String

				writeString(this.POINT_OF_IMPACT, dos);

				// String

				writeString(this.VEHICLE_DAMAGE, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_1, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_2, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_3, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE_TYPE, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_2, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.UNIQUE_ID, dos);

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.VEHICLE_ID, dos);

				// String

				writeString(this.STATE_REGISTRATION, dos);

				// String

				writeString(this.VEHICLE_TYPE, dos);

				// String

				writeString(this.VEHICLE_MAKE, dos);

				// String

				writeString(this.VEHICLE_MODEL, dos);

				// String

				writeString(this.VEHICLE_YEAR, dos);

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

				// String

				writeString(this.VEHICLE_OCCUPANTS, dos);

				// String

				writeString(this.DRIVER_SEX, dos);

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

				// String

				writeString(this.PRE_CRASH, dos);

				// String

				writeString(this.POINT_OF_IMPACT, dos);

				// String

				writeString(this.VEHICLE_DAMAGE, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_1, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_2, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_3, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE_TYPE, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_2, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("UNIQUE_ID=" + String.valueOf(UNIQUE_ID));
			sb.append(",COLLISION_ID=" + String.valueOf(COLLISION_ID));
			sb.append(",CRASH_DATE=" + CRASH_DATE);
			sb.append(",CRASH_TIME=" + CRASH_TIME);
			sb.append(",VEHICLE_ID=" + VEHICLE_ID);
			sb.append(",STATE_REGISTRATION=" + STATE_REGISTRATION);
			sb.append(",VEHICLE_TYPE=" + VEHICLE_TYPE);
			sb.append(",VEHICLE_MAKE=" + VEHICLE_MAKE);
			sb.append(",VEHICLE_MODEL=" + VEHICLE_MODEL);
			sb.append(",VEHICLE_YEAR=" + VEHICLE_YEAR);
			sb.append(",TRAVEL_DIRECTION=" + TRAVEL_DIRECTION);
			sb.append(",VEHICLE_OCCUPANTS=" + VEHICLE_OCCUPANTS);
			sb.append(",DRIVER_SEX=" + DRIVER_SEX);
			sb.append(",DRIVER_LICENSE_STATUS=" + DRIVER_LICENSE_STATUS);
			sb.append(",DRIVER_LICENSE_JURISDICTION=" + DRIVER_LICENSE_JURISDICTION);
			sb.append(",PRE_CRASH=" + PRE_CRASH);
			sb.append(",POINT_OF_IMPACT=" + POINT_OF_IMPACT);
			sb.append(",VEHICLE_DAMAGE=" + VEHICLE_DAMAGE);
			sb.append(",VEHICLE_DAMAGE_1=" + VEHICLE_DAMAGE_1);
			sb.append(",VEHICLE_DAMAGE_2=" + VEHICLE_DAMAGE_2);
			sb.append(",VEHICLE_DAMAGE_3=" + VEHICLE_DAMAGE_3);
			sb.append(",PUBLIC_PROPERTY_DAMAGE=" + PUBLIC_PROPERTY_DAMAGE);
			sb.append(",PUBLIC_PROPERTY_DAMAGE_TYPE=" + PUBLIC_PROPERTY_DAMAGE_TYPE);
			sb.append(",CONTRIBUTING_FACTOR_1=" + CONTRIBUTING_FACTOR_1);
			sb.append(",CONTRIBUTING_FACTOR_2=" + CONTRIBUTING_FACTOR_2);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (UNIQUE_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(UNIQUE_ID);
			}

			sb.append("|");

			if (COLLISION_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(COLLISION_ID);
			}

			sb.append("|");

			if (CRASH_DATE == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_DATE);
			}

			sb.append("|");

			if (CRASH_TIME == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_TIME);
			}

			sb.append("|");

			if (VEHICLE_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_ID);
			}

			sb.append("|");

			if (STATE_REGISTRATION == null) {
				sb.append("<null>");
			} else {
				sb.append(STATE_REGISTRATION);
			}

			sb.append("|");

			if (VEHICLE_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE);
			}

			sb.append("|");

			if (VEHICLE_MAKE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MAKE);
			}

			sb.append("|");

			if (VEHICLE_MODEL == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MODEL);
			}

			sb.append("|");

			if (VEHICLE_YEAR == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_YEAR);
			}

			sb.append("|");

			if (TRAVEL_DIRECTION == null) {
				sb.append("<null>");
			} else {
				sb.append(TRAVEL_DIRECTION);
			}

			sb.append("|");

			if (VEHICLE_OCCUPANTS == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_OCCUPANTS);
			}

			sb.append("|");

			if (DRIVER_SEX == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_SEX);
			}

			sb.append("|");

			if (DRIVER_LICENSE_STATUS == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_STATUS);
			}

			sb.append("|");

			if (DRIVER_LICENSE_JURISDICTION == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_JURISDICTION);
			}

			sb.append("|");

			if (PRE_CRASH == null) {
				sb.append("<null>");
			} else {
				sb.append(PRE_CRASH);
			}

			sb.append("|");

			if (POINT_OF_IMPACT == null) {
				sb.append("<null>");
			} else {
				sb.append(POINT_OF_IMPACT);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_1);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_2);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_3 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_3);
			}

			sb.append("|");

			if (PUBLIC_PROPERTY_DAMAGE == null) {
				sb.append("<null>");
			} else {
				sb.append(PUBLIC_PROPERTY_DAMAGE);
			}

			sb.append("|");

			if (PUBLIC_PROPERTY_DAMAGE_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(PUBLIC_PROPERTY_DAMAGE_TYPE);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_1);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_2);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_MOTOR_LoadToStgVehicle = new byte[0];
		static byte[] commonByteArray_MOTOR_LoadToStgVehicle = new byte[0];

		public Integer UNIQUE_ID;

		public Integer getUNIQUE_ID() {
			return this.UNIQUE_ID;
		}

		public Integer COLLISION_ID;

		public Integer getCOLLISION_ID() {
			return this.COLLISION_ID;
		}

		public String CRASH_DATE;

		public String getCRASH_DATE() {
			return this.CRASH_DATE;
		}

		public String CRASH_TIME;

		public String getCRASH_TIME() {
			return this.CRASH_TIME;
		}

		public String VEHICLE_ID;

		public String getVEHICLE_ID() {
			return this.VEHICLE_ID;
		}

		public String STATE_REGISTRATION;

		public String getSTATE_REGISTRATION() {
			return this.STATE_REGISTRATION;
		}

		public String VEHICLE_TYPE;

		public String getVEHICLE_TYPE() {
			return this.VEHICLE_TYPE;
		}

		public String VEHICLE_MAKE;

		public String getVEHICLE_MAKE() {
			return this.VEHICLE_MAKE;
		}

		public String VEHICLE_MODEL;

		public String getVEHICLE_MODEL() {
			return this.VEHICLE_MODEL;
		}

		public String VEHICLE_YEAR;

		public String getVEHICLE_YEAR() {
			return this.VEHICLE_YEAR;
		}

		public String TRAVEL_DIRECTION;

		public String getTRAVEL_DIRECTION() {
			return this.TRAVEL_DIRECTION;
		}

		public String VEHICLE_OCCUPANTS;

		public String getVEHICLE_OCCUPANTS() {
			return this.VEHICLE_OCCUPANTS;
		}

		public String DRIVER_SEX;

		public String getDRIVER_SEX() {
			return this.DRIVER_SEX;
		}

		public String DRIVER_LICENSE_STATUS;

		public String getDRIVER_LICENSE_STATUS() {
			return this.DRIVER_LICENSE_STATUS;
		}

		public String DRIVER_LICENSE_JURISDICTION;

		public String getDRIVER_LICENSE_JURISDICTION() {
			return this.DRIVER_LICENSE_JURISDICTION;
		}

		public String PRE_CRASH;

		public String getPRE_CRASH() {
			return this.PRE_CRASH;
		}

		public String POINT_OF_IMPACT;

		public String getPOINT_OF_IMPACT() {
			return this.POINT_OF_IMPACT;
		}

		public String VEHICLE_DAMAGE;

		public String getVEHICLE_DAMAGE() {
			return this.VEHICLE_DAMAGE;
		}

		public String VEHICLE_DAMAGE_1;

		public String getVEHICLE_DAMAGE_1() {
			return this.VEHICLE_DAMAGE_1;
		}

		public String VEHICLE_DAMAGE_2;

		public String getVEHICLE_DAMAGE_2() {
			return this.VEHICLE_DAMAGE_2;
		}

		public String VEHICLE_DAMAGE_3;

		public String getVEHICLE_DAMAGE_3() {
			return this.VEHICLE_DAMAGE_3;
		}

		public String PUBLIC_PROPERTY_DAMAGE;

		public String getPUBLIC_PROPERTY_DAMAGE() {
			return this.PUBLIC_PROPERTY_DAMAGE;
		}

		public String PUBLIC_PROPERTY_DAMAGE_TYPE;

		public String getPUBLIC_PROPERTY_DAMAGE_TYPE() {
			return this.PUBLIC_PROPERTY_DAMAGE_TYPE;
		}

		public String CONTRIBUTING_FACTOR_1;

		public String getCONTRIBUTING_FACTOR_1() {
			return this.CONTRIBUTING_FACTOR_1;
		}

		public String CONTRIBUTING_FACTOR_2;

		public String getCONTRIBUTING_FACTOR_2() {
			return this.CONTRIBUTING_FACTOR_2;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MOTOR_LoadToStgVehicle.length) {
					if (length < 1024 && commonByteArray_MOTOR_LoadToStgVehicle.length == 0) {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[1024];
					} else {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MOTOR_LoadToStgVehicle, 0, length);
				strReturn = new String(commonByteArray_MOTOR_LoadToStgVehicle, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MOTOR_LoadToStgVehicle.length) {
					if (length < 1024 && commonByteArray_MOTOR_LoadToStgVehicle.length == 0) {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[1024];
					} else {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MOTOR_LoadToStgVehicle, 0, length);
				strReturn = new String(commonByteArray_MOTOR_LoadToStgVehicle, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MOTOR_LoadToStgVehicle) {

				try {

					int length = 0;

					this.UNIQUE_ID = readInteger(dis);

					this.COLLISION_ID = readInteger(dis);

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.VEHICLE_ID = readString(dis);

					this.STATE_REGISTRATION = readString(dis);

					this.VEHICLE_TYPE = readString(dis);

					this.VEHICLE_MAKE = readString(dis);

					this.VEHICLE_MODEL = readString(dis);

					this.VEHICLE_YEAR = readString(dis);

					this.TRAVEL_DIRECTION = readString(dis);

					this.VEHICLE_OCCUPANTS = readString(dis);

					this.DRIVER_SEX = readString(dis);

					this.DRIVER_LICENSE_STATUS = readString(dis);

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

					this.PRE_CRASH = readString(dis);

					this.POINT_OF_IMPACT = readString(dis);

					this.VEHICLE_DAMAGE = readString(dis);

					this.VEHICLE_DAMAGE_1 = readString(dis);

					this.VEHICLE_DAMAGE_2 = readString(dis);

					this.VEHICLE_DAMAGE_3 = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE_TYPE = readString(dis);

					this.CONTRIBUTING_FACTOR_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_2 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MOTOR_LoadToStgVehicle) {

				try {

					int length = 0;

					this.UNIQUE_ID = readInteger(dis);

					this.COLLISION_ID = readInteger(dis);

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.VEHICLE_ID = readString(dis);

					this.STATE_REGISTRATION = readString(dis);

					this.VEHICLE_TYPE = readString(dis);

					this.VEHICLE_MAKE = readString(dis);

					this.VEHICLE_MODEL = readString(dis);

					this.VEHICLE_YEAR = readString(dis);

					this.TRAVEL_DIRECTION = readString(dis);

					this.VEHICLE_OCCUPANTS = readString(dis);

					this.DRIVER_SEX = readString(dis);

					this.DRIVER_LICENSE_STATUS = readString(dis);

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

					this.PRE_CRASH = readString(dis);

					this.POINT_OF_IMPACT = readString(dis);

					this.VEHICLE_DAMAGE = readString(dis);

					this.VEHICLE_DAMAGE_1 = readString(dis);

					this.VEHICLE_DAMAGE_2 = readString(dis);

					this.VEHICLE_DAMAGE_3 = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE_TYPE = readString(dis);

					this.CONTRIBUTING_FACTOR_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_2 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.UNIQUE_ID, dos);

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.VEHICLE_ID, dos);

				// String

				writeString(this.STATE_REGISTRATION, dos);

				// String

				writeString(this.VEHICLE_TYPE, dos);

				// String

				writeString(this.VEHICLE_MAKE, dos);

				// String

				writeString(this.VEHICLE_MODEL, dos);

				// String

				writeString(this.VEHICLE_YEAR, dos);

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

				// String

				writeString(this.VEHICLE_OCCUPANTS, dos);

				// String

				writeString(this.DRIVER_SEX, dos);

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

				// String

				writeString(this.PRE_CRASH, dos);

				// String

				writeString(this.POINT_OF_IMPACT, dos);

				// String

				writeString(this.VEHICLE_DAMAGE, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_1, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_2, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_3, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE_TYPE, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_2, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.UNIQUE_ID, dos);

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.VEHICLE_ID, dos);

				// String

				writeString(this.STATE_REGISTRATION, dos);

				// String

				writeString(this.VEHICLE_TYPE, dos);

				// String

				writeString(this.VEHICLE_MAKE, dos);

				// String

				writeString(this.VEHICLE_MODEL, dos);

				// String

				writeString(this.VEHICLE_YEAR, dos);

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

				// String

				writeString(this.VEHICLE_OCCUPANTS, dos);

				// String

				writeString(this.DRIVER_SEX, dos);

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

				// String

				writeString(this.PRE_CRASH, dos);

				// String

				writeString(this.POINT_OF_IMPACT, dos);

				// String

				writeString(this.VEHICLE_DAMAGE, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_1, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_2, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_3, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE_TYPE, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_2, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("UNIQUE_ID=" + String.valueOf(UNIQUE_ID));
			sb.append(",COLLISION_ID=" + String.valueOf(COLLISION_ID));
			sb.append(",CRASH_DATE=" + CRASH_DATE);
			sb.append(",CRASH_TIME=" + CRASH_TIME);
			sb.append(",VEHICLE_ID=" + VEHICLE_ID);
			sb.append(",STATE_REGISTRATION=" + STATE_REGISTRATION);
			sb.append(",VEHICLE_TYPE=" + VEHICLE_TYPE);
			sb.append(",VEHICLE_MAKE=" + VEHICLE_MAKE);
			sb.append(",VEHICLE_MODEL=" + VEHICLE_MODEL);
			sb.append(",VEHICLE_YEAR=" + VEHICLE_YEAR);
			sb.append(",TRAVEL_DIRECTION=" + TRAVEL_DIRECTION);
			sb.append(",VEHICLE_OCCUPANTS=" + VEHICLE_OCCUPANTS);
			sb.append(",DRIVER_SEX=" + DRIVER_SEX);
			sb.append(",DRIVER_LICENSE_STATUS=" + DRIVER_LICENSE_STATUS);
			sb.append(",DRIVER_LICENSE_JURISDICTION=" + DRIVER_LICENSE_JURISDICTION);
			sb.append(",PRE_CRASH=" + PRE_CRASH);
			sb.append(",POINT_OF_IMPACT=" + POINT_OF_IMPACT);
			sb.append(",VEHICLE_DAMAGE=" + VEHICLE_DAMAGE);
			sb.append(",VEHICLE_DAMAGE_1=" + VEHICLE_DAMAGE_1);
			sb.append(",VEHICLE_DAMAGE_2=" + VEHICLE_DAMAGE_2);
			sb.append(",VEHICLE_DAMAGE_3=" + VEHICLE_DAMAGE_3);
			sb.append(",PUBLIC_PROPERTY_DAMAGE=" + PUBLIC_PROPERTY_DAMAGE);
			sb.append(",PUBLIC_PROPERTY_DAMAGE_TYPE=" + PUBLIC_PROPERTY_DAMAGE_TYPE);
			sb.append(",CONTRIBUTING_FACTOR_1=" + CONTRIBUTING_FACTOR_1);
			sb.append(",CONTRIBUTING_FACTOR_2=" + CONTRIBUTING_FACTOR_2);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (UNIQUE_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(UNIQUE_ID);
			}

			sb.append("|");

			if (COLLISION_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(COLLISION_ID);
			}

			sb.append("|");

			if (CRASH_DATE == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_DATE);
			}

			sb.append("|");

			if (CRASH_TIME == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_TIME);
			}

			sb.append("|");

			if (VEHICLE_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_ID);
			}

			sb.append("|");

			if (STATE_REGISTRATION == null) {
				sb.append("<null>");
			} else {
				sb.append(STATE_REGISTRATION);
			}

			sb.append("|");

			if (VEHICLE_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE);
			}

			sb.append("|");

			if (VEHICLE_MAKE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MAKE);
			}

			sb.append("|");

			if (VEHICLE_MODEL == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MODEL);
			}

			sb.append("|");

			if (VEHICLE_YEAR == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_YEAR);
			}

			sb.append("|");

			if (TRAVEL_DIRECTION == null) {
				sb.append("<null>");
			} else {
				sb.append(TRAVEL_DIRECTION);
			}

			sb.append("|");

			if (VEHICLE_OCCUPANTS == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_OCCUPANTS);
			}

			sb.append("|");

			if (DRIVER_SEX == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_SEX);
			}

			sb.append("|");

			if (DRIVER_LICENSE_STATUS == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_STATUS);
			}

			sb.append("|");

			if (DRIVER_LICENSE_JURISDICTION == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_JURISDICTION);
			}

			sb.append("|");

			if (PRE_CRASH == null) {
				sb.append("<null>");
			} else {
				sb.append(PRE_CRASH);
			}

			sb.append("|");

			if (POINT_OF_IMPACT == null) {
				sb.append("<null>");
			} else {
				sb.append(POINT_OF_IMPACT);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_1);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_2);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_3 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_3);
			}

			sb.append("|");

			if (PUBLIC_PROPERTY_DAMAGE == null) {
				sb.append("<null>");
			} else {
				sb.append(PUBLIC_PROPERTY_DAMAGE);
			}

			sb.append("|");

			if (PUBLIC_PROPERTY_DAMAGE_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(PUBLIC_PROPERTY_DAMAGE_TYPE);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_1);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_2);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				row2Struct row2 = new row2Struct();

				/**
				 * [tLogRow_1 begin ] start
				 */

				ok_Hash.put("tLogRow_1", false);
				start_Hash.put("tLogRow_1", System.currentTimeMillis());

				currentComponent = "tLogRow_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row2");
				}

				int tos_count_tLogRow_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tLogRow_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tLogRow_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tLogRow_1 = new StringBuilder();
							log4jParamters_tLogRow_1.append("Parameters:");
							log4jParamters_tLogRow_1.append("BASIC_MODE" + " = " + "true");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("TABLE_PRINT" + " = " + "false");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("VERTICAL" + " = " + "false");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("FIELDSEPARATOR" + " = " + "\"|\"");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("PRINT_HEADER" + " = " + "false");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("PRINT_UNIQUE_NAME" + " = " + "false");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("PRINT_COLNAMES" + " = " + "false");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("USE_FIXED_LENGTH" + " = " + "false");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
							log4jParamters_tLogRow_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tLogRow_1 - " + (log4jParamters_tLogRow_1));
						}
					}
					new BytesLimit65535_tLogRow_1().limitLog4jByte();
				}

				///////////////////////

				final String OUTPUT_FIELD_SEPARATOR_tLogRow_1 = "|";
				java.io.PrintStream consoleOut_tLogRow_1 = null;

				StringBuilder strBuffer_tLogRow_1 = null;
				int nb_line_tLogRow_1 = 0;
///////////////////////    			

				/**
				 * [tLogRow_1 begin ] stop
				 */

				/**
				 * [tUniqRow_1 begin ] start
				 */

				ok_Hash.put("tUniqRow_1", false);
				start_Hash.put("tUniqRow_1", System.currentTimeMillis());

				currentComponent = "tUniqRow_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tUniqRow_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_1 = new StringBuilder();
							log4jParamters_tUniqRow_1.append("Parameters:");
							log4jParamters_tUniqRow_1.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("UNIQUE_ID")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("true")
									+ ", SCHEMA_COLUMN=" + ("COLLISION_ID") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("CRASH_DATE")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("CRASH_TIME") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_ID")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("STATE_REGISTRATION") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_TYPE")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_MAKE") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_MODEL")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_YEAR") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("TRAVEL_DIRECTION")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_OCCUPANTS") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("DRIVER_SEX")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("DRIVER_LICENSE_STATUS") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN="
									+ ("DRIVER_LICENSE_JURISDICTION") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("PRE_CRASH")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("POINT_OF_IMPACT") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE_1") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE_2")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE_3") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("PUBLIC_PROPERTY_DAMAGE")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PUBLIC_PROPERTY_DAMAGE_TYPE") + "}, {CASE_SENSITIVE="
									+ ("false") + ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN="
									+ ("CONTRIBUTING_FACTOR_1") + "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE="
									+ ("false") + ", SCHEMA_COLUMN=" + ("CONTRIBUTING_FACTOR_2") + "}]");
							log4jParamters_tUniqRow_1.append(" | ");
							log4jParamters_tUniqRow_1.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_1.append(" | ");
							log4jParamters_tUniqRow_1.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_1.append(" | ");
							log4jParamters_tUniqRow_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_1 - " + (log4jParamters_tUniqRow_1));
						}
					}
					new BytesLimit65535_tUniqRow_1().limitLog4jByte();
				}

				class KeyStruct_tUniqRow_1 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					Integer COLLISION_ID;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.COLLISION_ID == null) ? 0 : this.COLLISION_ID.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_1 other = (KeyStruct_tUniqRow_1) obj;

						if (this.COLLISION_ID == null) {
							if (other.COLLISION_ID != null)
								return false;

						} else if (!this.COLLISION_ID.equals(other.COLLISION_ID))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_1 = 0;
				int nb_duplicates_tUniqRow_1 = 0;
				log.debug("tUniqRow_1 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_1 finder_tUniqRow_1 = new KeyStruct_tUniqRow_1();
				java.util.Set<KeyStruct_tUniqRow_1> keystUniqRow_1 = new java.util.HashSet<KeyStruct_tUniqRow_1>();

				/**
				 * [tUniqRow_1 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_1", false);
				start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_1";

				int tos_count_tFileInputDelimited_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileInputDelimited_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileInputDelimited_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileInputDelimited_1 = new StringBuilder();
							log4jParamters_tFileInputDelimited_1.append("Parameters:");
							log4jParamters_tFileInputDelimited_1.append("FILENAME" + " = "
									+ "\"//Mac/Home/Downloads/Motor_Vehicle_Collisions_-_Vehicles.tsv\"");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("CSV_OPTION" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("ROWSEPARATOR" + " = " + "\"\\n\"");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("FIELDSEPARATOR" + " = " + "\"\\t\"");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("HEADER" + " = " + "1");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("FOOTER" + " = " + "0");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("LIMIT" + " = " + "");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("REMOVE_EMPTY_ROW" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("UNCOMPRESS" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("RANDOM" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("TRIMALL" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("TRIMSELECT" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("UNIQUE_ID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("COLLISION_ID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("CRASH_DATE")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("CRASH_TIME") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_ID") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("STATE_REGISTRATION") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_TYPE") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_MAKE") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_MODEL") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_YEAR") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("TRAVEL_DIRECTION") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_OCCUPANTS") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("DRIVER_SEX") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("DRIVER_LICENSE_STATUS") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("DRIVER_LICENSE_JURISDICTION") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("PRE_CRASH") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("POINT_OF_IMPACT")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE_1") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE_2") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE_3") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PUBLIC_PROPERTY_DAMAGE") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PUBLIC_PROPERTY_DAMAGE_TYPE") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("CONTRIBUTING_FACTOR_1") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("CONTRIBUTING_FACTOR_2") + "}]");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("CHECK_FIELDS_NUM" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("CHECK_DATE" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("ENCODING" + " = " + "\"UTF-8\"");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("SPLITRECORD" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("ENABLE_DECODE" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileInputDelimited_1 - " + (log4jParamters_tFileInputDelimited_1));
						}
					}
					new BytesLimit65535_tFileInputDelimited_1().limitLog4jByte();
				}

				final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try {

					Object filename_tFileInputDelimited_1 = "//Mac/Home/Downloads/Motor_Vehicle_Collisions_-_Vehicles.tsv";
					if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
						if (footer_value_tFileInputDelimited_1 > 0 || random_value_tFileInputDelimited_1 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(
								"//Mac/Home/Downloads/Motor_Vehicle_Collisions_-_Vehicles.tsv", "UTF-8", "\t", "\n",
								false, 1, 0, limit_tFileInputDelimited_1, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());

						log.error("tFileInputDelimited_1 - " + e.getMessage());

						System.err.println(e.getMessage());

					}

					log.info("tFileInputDelimited_1 - Retrieving records from the datasource.");

					while (fid_tFileInputDelimited_1 != null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();

						row1 = null;

						boolean whetherReject_tFileInputDelimited_1 = false;
						row1 = new row1Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_1 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_1 = 0;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.UNIQUE_ID = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"UNIQUE_ID", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.UNIQUE_ID = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 1;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.COLLISION_ID = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"COLLISION_ID", "row1", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row1.COLLISION_ID = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 2;

							row1.CRASH_DATE = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 3;

							row1.CRASH_TIME = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 4;

							row1.VEHICLE_ID = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 5;

							row1.STATE_REGISTRATION = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 6;

							row1.VEHICLE_TYPE = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 7;

							row1.VEHICLE_MAKE = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 8;

							row1.VEHICLE_MODEL = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 9;

							row1.VEHICLE_YEAR = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 10;

							row1.TRAVEL_DIRECTION = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 11;

							row1.VEHICLE_OCCUPANTS = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 12;

							row1.DRIVER_SEX = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 13;

							row1.DRIVER_LICENSE_STATUS = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 14;

							row1.DRIVER_LICENSE_JURISDICTION = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 15;

							row1.PRE_CRASH = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 16;

							row1.POINT_OF_IMPACT = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 17;

							row1.VEHICLE_DAMAGE = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 18;

							row1.VEHICLE_DAMAGE_1 = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 19;

							row1.VEHICLE_DAMAGE_2 = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 20;

							row1.VEHICLE_DAMAGE_3 = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 21;

							row1.PUBLIC_PROPERTY_DAMAGE = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 22;

							row1.PUBLIC_PROPERTY_DAMAGE_TYPE = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 23;

							row1.CONTRIBUTING_FACTOR_1 = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 24;

							row1.CONTRIBUTING_FACTOR_2 = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							if (rowstate_tFileInputDelimited_1.getException() != null) {
								throw rowstate_tFileInputDelimited_1.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_1 = true;

							log.error("tFileInputDelimited_1 - " + e.getMessage());

							System.err.println(e.getMessage());
							row1 = null;

						}

						log.debug("tFileInputDelimited_1 - Retrieving the record "
								+ fid_tFileInputDelimited_1.getRowNumber() + ".");

						/**
						 * [tFileInputDelimited_1 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_1 main ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						tos_count_tFileInputDelimited_1++;

						/**
						 * [tFileInputDelimited_1 main ] stop
						 */

						/**
						 * [tFileInputDelimited_1 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_begin ] stop
						 */
// Start of branch "row1"
						if (row1 != null) {

							/**
							 * [tUniqRow_1 main ] start
							 */

							currentComponent = "tUniqRow_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row1"

								);
							}

							if (log.isTraceEnabled()) {
								log.trace("row1 - " + (row1 == null ? "" : row1.toLogString()));
							}

							row2 = null;
							finder_tUniqRow_1.COLLISION_ID = row1.COLLISION_ID;
							finder_tUniqRow_1.hashCodeDirty = true;
							if (!keystUniqRow_1.contains(finder_tUniqRow_1)) {
								KeyStruct_tUniqRow_1 new_tUniqRow_1 = new KeyStruct_tUniqRow_1();

								new_tUniqRow_1.COLLISION_ID = row1.COLLISION_ID;

								keystUniqRow_1.add(new_tUniqRow_1);
								if (row2 == null) {

									log.trace("tUniqRow_1 - Writing the unique record " + (nb_uniques_tUniqRow_1 + 1)
											+ " into row2.");

									row2 = new row2Struct();
								}
								row2.UNIQUE_ID = row1.UNIQUE_ID;
								row2.COLLISION_ID = row1.COLLISION_ID;
								row2.CRASH_DATE = row1.CRASH_DATE;
								row2.CRASH_TIME = row1.CRASH_TIME;
								row2.VEHICLE_ID = row1.VEHICLE_ID;
								row2.STATE_REGISTRATION = row1.STATE_REGISTRATION;
								row2.VEHICLE_TYPE = row1.VEHICLE_TYPE;
								row2.VEHICLE_MAKE = row1.VEHICLE_MAKE;
								row2.VEHICLE_MODEL = row1.VEHICLE_MODEL;
								row2.VEHICLE_YEAR = row1.VEHICLE_YEAR;
								row2.TRAVEL_DIRECTION = row1.TRAVEL_DIRECTION;
								row2.VEHICLE_OCCUPANTS = row1.VEHICLE_OCCUPANTS;
								row2.DRIVER_SEX = row1.DRIVER_SEX;
								row2.DRIVER_LICENSE_STATUS = row1.DRIVER_LICENSE_STATUS;
								row2.DRIVER_LICENSE_JURISDICTION = row1.DRIVER_LICENSE_JURISDICTION;
								row2.PRE_CRASH = row1.PRE_CRASH;
								row2.POINT_OF_IMPACT = row1.POINT_OF_IMPACT;
								row2.VEHICLE_DAMAGE = row1.VEHICLE_DAMAGE;
								row2.VEHICLE_DAMAGE_1 = row1.VEHICLE_DAMAGE_1;
								row2.VEHICLE_DAMAGE_2 = row1.VEHICLE_DAMAGE_2;
								row2.VEHICLE_DAMAGE_3 = row1.VEHICLE_DAMAGE_3;
								row2.PUBLIC_PROPERTY_DAMAGE = row1.PUBLIC_PROPERTY_DAMAGE;
								row2.PUBLIC_PROPERTY_DAMAGE_TYPE = row1.PUBLIC_PROPERTY_DAMAGE_TYPE;
								row2.CONTRIBUTING_FACTOR_1 = row1.CONTRIBUTING_FACTOR_1;
								row2.CONTRIBUTING_FACTOR_2 = row1.CONTRIBUTING_FACTOR_2;
								nb_uniques_tUniqRow_1++;
							} else {
								nb_duplicates_tUniqRow_1++;
							}

							tos_count_tUniqRow_1++;

							/**
							 * [tUniqRow_1 main ] stop
							 */

							/**
							 * [tUniqRow_1 process_data_begin ] start
							 */

							currentComponent = "tUniqRow_1";

							/**
							 * [tUniqRow_1 process_data_begin ] stop
							 */
// Start of branch "row2"
							if (row2 != null) {

								/**
								 * [tLogRow_1 main ] start
								 */

								currentComponent = "tLogRow_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "row2"

									);
								}

								if (log.isTraceEnabled()) {
									log.trace("row2 - " + (row2 == null ? "" : row2.toLogString()));
								}

///////////////////////		

								strBuffer_tLogRow_1 = new StringBuilder();

								if (row2.UNIQUE_ID != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.UNIQUE_ID));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.COLLISION_ID != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.COLLISION_ID));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.CRASH_DATE != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.CRASH_DATE));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.CRASH_TIME != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.CRASH_TIME));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.VEHICLE_ID != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.VEHICLE_ID));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.STATE_REGISTRATION != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.STATE_REGISTRATION));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.VEHICLE_TYPE != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.VEHICLE_TYPE));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.VEHICLE_MAKE != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.VEHICLE_MAKE));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.VEHICLE_MODEL != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.VEHICLE_MODEL));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.VEHICLE_YEAR != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.VEHICLE_YEAR));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.TRAVEL_DIRECTION != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.TRAVEL_DIRECTION));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.VEHICLE_OCCUPANTS != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.VEHICLE_OCCUPANTS));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.DRIVER_SEX != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.DRIVER_SEX));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.DRIVER_LICENSE_STATUS != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.DRIVER_LICENSE_STATUS));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.DRIVER_LICENSE_JURISDICTION != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.DRIVER_LICENSE_JURISDICTION));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.PRE_CRASH != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.PRE_CRASH));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.POINT_OF_IMPACT != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.POINT_OF_IMPACT));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.VEHICLE_DAMAGE != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.VEHICLE_DAMAGE));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.VEHICLE_DAMAGE_1 != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.VEHICLE_DAMAGE_1));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.VEHICLE_DAMAGE_2 != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.VEHICLE_DAMAGE_2));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.VEHICLE_DAMAGE_3 != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.VEHICLE_DAMAGE_3));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.PUBLIC_PROPERTY_DAMAGE != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.PUBLIC_PROPERTY_DAMAGE));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.PUBLIC_PROPERTY_DAMAGE_TYPE != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.PUBLIC_PROPERTY_DAMAGE_TYPE));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.CONTRIBUTING_FACTOR_1 != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.CONTRIBUTING_FACTOR_1));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row2.CONTRIBUTING_FACTOR_2 != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row2.CONTRIBUTING_FACTOR_2));

								} //

								if (globalMap.get("tLogRow_CONSOLE") != null) {
									consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
								} else {
									consoleOut_tLogRow_1 = new java.io.PrintStream(
											new java.io.BufferedOutputStream(System.out));
									globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_1);
								}
								log.info("tLogRow_1 - Content of row " + (nb_line_tLogRow_1 + 1) + ": "
										+ strBuffer_tLogRow_1.toString());
								consoleOut_tLogRow_1.println(strBuffer_tLogRow_1.toString());
								consoleOut_tLogRow_1.flush();
								nb_line_tLogRow_1++;
//////

//////                    

///////////////////////    			

								tos_count_tLogRow_1++;

								/**
								 * [tLogRow_1 main ] stop
								 */

								/**
								 * [tLogRow_1 process_data_begin ] start
								 */

								currentComponent = "tLogRow_1";

								/**
								 * [tLogRow_1 process_data_begin ] stop
								 */

								/**
								 * [tLogRow_1 process_data_end ] start
								 */

								currentComponent = "tLogRow_1";

								/**
								 * [tLogRow_1 process_data_end ] stop
								 */

							} // End of branch "row2"

							/**
							 * [tUniqRow_1 process_data_end ] start
							 */

							currentComponent = "tUniqRow_1";

							/**
							 * [tUniqRow_1 process_data_end ] stop
							 */

						} // End of branch "row1"

						/**
						 * [tFileInputDelimited_1 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_1 end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

					}
				} finally {
					if (!((Object) ("//Mac/Home/Downloads/Motor_Vehicle_Collisions_-_Vehicles.tsv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_1 != null) {
							fid_tFileInputDelimited_1.close();
						}
					}
					if (fid_tFileInputDelimited_1 != null) {
						globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());

						log.info("tFileInputDelimited_1 - Retrieved records count: "
								+ fid_tFileInputDelimited_1.getRowNumber() + ".");

					}
				}

				if (log.isDebugEnabled())
					log.debug("tFileInputDelimited_1 - " + ("Done."));

				ok_Hash.put("tFileInputDelimited_1", true);
				end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_1 end ] stop
				 */

				/**
				 * [tUniqRow_1 end ] start
				 */

				currentComponent = "tUniqRow_1";

				globalMap.put("tUniqRow_1_NB_UNIQUES", nb_uniques_tUniqRow_1);
				globalMap.put("tUniqRow_1_NB_DUPLICATES", nb_duplicates_tUniqRow_1);
				log.info("tUniqRow_1 - Unique records count: " + (nb_uniques_tUniqRow_1) + " .");
				log.info("tUniqRow_1 - Duplicate records count: " + (nb_duplicates_tUniqRow_1) + " .");

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_1 - " + ("Done."));

				ok_Hash.put("tUniqRow_1", true);
				end_Hash.put("tUniqRow_1", System.currentTimeMillis());

				/**
				 * [tUniqRow_1 end ] stop
				 */

				/**
				 * [tLogRow_1 end ] start
				 */

				currentComponent = "tLogRow_1";

//////
//////
				globalMap.put("tLogRow_1_NB_LINE", nb_line_tLogRow_1);
				if (log.isInfoEnabled())
					log.info("tLogRow_1 - " + ("Printed row count: ") + (nb_line_tLogRow_1) + ("."));

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row2");
				}

				if (log.isDebugEnabled())
					log.debug("tLogRow_1 - " + ("Done."));

				ok_Hash.put("tLogRow_1", true);
				end_Hash.put("tLogRow_1", System.currentTimeMillis());

				/**
				 * [tLogRow_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_1 finally ] start
				 */

				currentComponent = "tFileInputDelimited_1";

				/**
				 * [tFileInputDelimited_1 finally ] stop
				 */

				/**
				 * [tUniqRow_1 finally ] start
				 */

				currentComponent = "tUniqRow_1";

				/**
				 * [tUniqRow_1 finally ] stop
				 */

				/**
				 * [tLogRow_1 finally ] start
				 */

				currentComponent = "tLogRow_1";

				/**
				 * [tLogRow_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}

	public static class outStruct implements routines.system.IPersistableRow<outStruct> {
		final static byte[] commonByteArrayLock_MOTOR_LoadToStgVehicle = new byte[0];
		static byte[] commonByteArray_MOTOR_LoadToStgVehicle = new byte[0];

		public Integer UNIQUE_ID;

		public Integer getUNIQUE_ID() {
			return this.UNIQUE_ID;
		}

		public Integer COLLISION_ID;

		public Integer getCOLLISION_ID() {
			return this.COLLISION_ID;
		}

		public String CRASH_DATE;

		public String getCRASH_DATE() {
			return this.CRASH_DATE;
		}

		public String CRASH_TIME;

		public String getCRASH_TIME() {
			return this.CRASH_TIME;
		}

		public String VEHICLE_ID;

		public String getVEHICLE_ID() {
			return this.VEHICLE_ID;
		}

		public String STATE_REGISTRATION;

		public String getSTATE_REGISTRATION() {
			return this.STATE_REGISTRATION;
		}

		public String VEHICLE_TYPE;

		public String getVEHICLE_TYPE() {
			return this.VEHICLE_TYPE;
		}

		public String VEHICLE_MAKE;

		public String getVEHICLE_MAKE() {
			return this.VEHICLE_MAKE;
		}

		public String VEHICLE_MODEL;

		public String getVEHICLE_MODEL() {
			return this.VEHICLE_MODEL;
		}

		public String VEHICLE_YEAR;

		public String getVEHICLE_YEAR() {
			return this.VEHICLE_YEAR;
		}

		public String TRAVEL_DIRECTION;

		public String getTRAVEL_DIRECTION() {
			return this.TRAVEL_DIRECTION;
		}

		public String VEHICLE_OCCUPANTS;

		public String getVEHICLE_OCCUPANTS() {
			return this.VEHICLE_OCCUPANTS;
		}

		public String DRIVER_SEX;

		public String getDRIVER_SEX() {
			return this.DRIVER_SEX;
		}

		public String DRIVER_LICENSE_STATUS;

		public String getDRIVER_LICENSE_STATUS() {
			return this.DRIVER_LICENSE_STATUS;
		}

		public String DRIVER_LICENSE_JURISDICTION;

		public String getDRIVER_LICENSE_JURISDICTION() {
			return this.DRIVER_LICENSE_JURISDICTION;
		}

		public String PRE_CRASH;

		public String getPRE_CRASH() {
			return this.PRE_CRASH;
		}

		public String POINT_OF_IMPACT;

		public String getPOINT_OF_IMPACT() {
			return this.POINT_OF_IMPACT;
		}

		public String VEHICLE_DAMAGE;

		public String getVEHICLE_DAMAGE() {
			return this.VEHICLE_DAMAGE;
		}

		public String VEHICLE_DAMAGE_1;

		public String getVEHICLE_DAMAGE_1() {
			return this.VEHICLE_DAMAGE_1;
		}

		public String VEHICLE_DAMAGE_2;

		public String getVEHICLE_DAMAGE_2() {
			return this.VEHICLE_DAMAGE_2;
		}

		public String VEHICLE_DAMAGE_3;

		public String getVEHICLE_DAMAGE_3() {
			return this.VEHICLE_DAMAGE_3;
		}

		public String PUBLIC_PROPERTY_DAMAGE;

		public String getPUBLIC_PROPERTY_DAMAGE() {
			return this.PUBLIC_PROPERTY_DAMAGE;
		}

		public String PUBLIC_PROPERTY_DAMAGE_TYPE;

		public String getPUBLIC_PROPERTY_DAMAGE_TYPE() {
			return this.PUBLIC_PROPERTY_DAMAGE_TYPE;
		}

		public String CONTRIBUTING_FACTOR_1;

		public String getCONTRIBUTING_FACTOR_1() {
			return this.CONTRIBUTING_FACTOR_1;
		}

		public String CONTRIBUTING_FACTOR_2;

		public String getCONTRIBUTING_FACTOR_2() {
			return this.CONTRIBUTING_FACTOR_2;
		}

		public String DI_PID;

		public String getDI_PID() {
			return this.DI_PID;
		}

		public java.util.Date DI_Create_Date;

		public java.util.Date getDI_Create_Date() {
			return this.DI_Create_Date;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MOTOR_LoadToStgVehicle.length) {
					if (length < 1024 && commonByteArray_MOTOR_LoadToStgVehicle.length == 0) {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[1024];
					} else {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MOTOR_LoadToStgVehicle, 0, length);
				strReturn = new String(commonByteArray_MOTOR_LoadToStgVehicle, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MOTOR_LoadToStgVehicle.length) {
					if (length < 1024 && commonByteArray_MOTOR_LoadToStgVehicle.length == 0) {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[1024];
					} else {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MOTOR_LoadToStgVehicle, 0, length);
				strReturn = new String(commonByteArray_MOTOR_LoadToStgVehicle, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MOTOR_LoadToStgVehicle) {

				try {

					int length = 0;

					this.UNIQUE_ID = readInteger(dis);

					this.COLLISION_ID = readInteger(dis);

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.VEHICLE_ID = readString(dis);

					this.STATE_REGISTRATION = readString(dis);

					this.VEHICLE_TYPE = readString(dis);

					this.VEHICLE_MAKE = readString(dis);

					this.VEHICLE_MODEL = readString(dis);

					this.VEHICLE_YEAR = readString(dis);

					this.TRAVEL_DIRECTION = readString(dis);

					this.VEHICLE_OCCUPANTS = readString(dis);

					this.DRIVER_SEX = readString(dis);

					this.DRIVER_LICENSE_STATUS = readString(dis);

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

					this.PRE_CRASH = readString(dis);

					this.POINT_OF_IMPACT = readString(dis);

					this.VEHICLE_DAMAGE = readString(dis);

					this.VEHICLE_DAMAGE_1 = readString(dis);

					this.VEHICLE_DAMAGE_2 = readString(dis);

					this.VEHICLE_DAMAGE_3 = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE_TYPE = readString(dis);

					this.CONTRIBUTING_FACTOR_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_2 = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MOTOR_LoadToStgVehicle) {

				try {

					int length = 0;

					this.UNIQUE_ID = readInteger(dis);

					this.COLLISION_ID = readInteger(dis);

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.VEHICLE_ID = readString(dis);

					this.STATE_REGISTRATION = readString(dis);

					this.VEHICLE_TYPE = readString(dis);

					this.VEHICLE_MAKE = readString(dis);

					this.VEHICLE_MODEL = readString(dis);

					this.VEHICLE_YEAR = readString(dis);

					this.TRAVEL_DIRECTION = readString(dis);

					this.VEHICLE_OCCUPANTS = readString(dis);

					this.DRIVER_SEX = readString(dis);

					this.DRIVER_LICENSE_STATUS = readString(dis);

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

					this.PRE_CRASH = readString(dis);

					this.POINT_OF_IMPACT = readString(dis);

					this.VEHICLE_DAMAGE = readString(dis);

					this.VEHICLE_DAMAGE_1 = readString(dis);

					this.VEHICLE_DAMAGE_2 = readString(dis);

					this.VEHICLE_DAMAGE_3 = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE_TYPE = readString(dis);

					this.CONTRIBUTING_FACTOR_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_2 = readString(dis);

					this.DI_PID = readString(dis);

					this.DI_Create_Date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.UNIQUE_ID, dos);

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.VEHICLE_ID, dos);

				// String

				writeString(this.STATE_REGISTRATION, dos);

				// String

				writeString(this.VEHICLE_TYPE, dos);

				// String

				writeString(this.VEHICLE_MAKE, dos);

				// String

				writeString(this.VEHICLE_MODEL, dos);

				// String

				writeString(this.VEHICLE_YEAR, dos);

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

				// String

				writeString(this.VEHICLE_OCCUPANTS, dos);

				// String

				writeString(this.DRIVER_SEX, dos);

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

				// String

				writeString(this.PRE_CRASH, dos);

				// String

				writeString(this.POINT_OF_IMPACT, dos);

				// String

				writeString(this.VEHICLE_DAMAGE, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_1, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_2, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_3, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE_TYPE, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_2, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.UNIQUE_ID, dos);

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.VEHICLE_ID, dos);

				// String

				writeString(this.STATE_REGISTRATION, dos);

				// String

				writeString(this.VEHICLE_TYPE, dos);

				// String

				writeString(this.VEHICLE_MAKE, dos);

				// String

				writeString(this.VEHICLE_MODEL, dos);

				// String

				writeString(this.VEHICLE_YEAR, dos);

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

				// String

				writeString(this.VEHICLE_OCCUPANTS, dos);

				// String

				writeString(this.DRIVER_SEX, dos);

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

				// String

				writeString(this.PRE_CRASH, dos);

				// String

				writeString(this.POINT_OF_IMPACT, dos);

				// String

				writeString(this.VEHICLE_DAMAGE, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_1, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_2, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_3, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE_TYPE, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_2, dos);

				// String

				writeString(this.DI_PID, dos);

				// java.util.Date

				writeDate(this.DI_Create_Date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("UNIQUE_ID=" + String.valueOf(UNIQUE_ID));
			sb.append(",COLLISION_ID=" + String.valueOf(COLLISION_ID));
			sb.append(",CRASH_DATE=" + CRASH_DATE);
			sb.append(",CRASH_TIME=" + CRASH_TIME);
			sb.append(",VEHICLE_ID=" + VEHICLE_ID);
			sb.append(",STATE_REGISTRATION=" + STATE_REGISTRATION);
			sb.append(",VEHICLE_TYPE=" + VEHICLE_TYPE);
			sb.append(",VEHICLE_MAKE=" + VEHICLE_MAKE);
			sb.append(",VEHICLE_MODEL=" + VEHICLE_MODEL);
			sb.append(",VEHICLE_YEAR=" + VEHICLE_YEAR);
			sb.append(",TRAVEL_DIRECTION=" + TRAVEL_DIRECTION);
			sb.append(",VEHICLE_OCCUPANTS=" + VEHICLE_OCCUPANTS);
			sb.append(",DRIVER_SEX=" + DRIVER_SEX);
			sb.append(",DRIVER_LICENSE_STATUS=" + DRIVER_LICENSE_STATUS);
			sb.append(",DRIVER_LICENSE_JURISDICTION=" + DRIVER_LICENSE_JURISDICTION);
			sb.append(",PRE_CRASH=" + PRE_CRASH);
			sb.append(",POINT_OF_IMPACT=" + POINT_OF_IMPACT);
			sb.append(",VEHICLE_DAMAGE=" + VEHICLE_DAMAGE);
			sb.append(",VEHICLE_DAMAGE_1=" + VEHICLE_DAMAGE_1);
			sb.append(",VEHICLE_DAMAGE_2=" + VEHICLE_DAMAGE_2);
			sb.append(",VEHICLE_DAMAGE_3=" + VEHICLE_DAMAGE_3);
			sb.append(",PUBLIC_PROPERTY_DAMAGE=" + PUBLIC_PROPERTY_DAMAGE);
			sb.append(",PUBLIC_PROPERTY_DAMAGE_TYPE=" + PUBLIC_PROPERTY_DAMAGE_TYPE);
			sb.append(",CONTRIBUTING_FACTOR_1=" + CONTRIBUTING_FACTOR_1);
			sb.append(",CONTRIBUTING_FACTOR_2=" + CONTRIBUTING_FACTOR_2);
			sb.append(",DI_PID=" + DI_PID);
			sb.append(",DI_Create_Date=" + String.valueOf(DI_Create_Date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (UNIQUE_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(UNIQUE_ID);
			}

			sb.append("|");

			if (COLLISION_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(COLLISION_ID);
			}

			sb.append("|");

			if (CRASH_DATE == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_DATE);
			}

			sb.append("|");

			if (CRASH_TIME == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_TIME);
			}

			sb.append("|");

			if (VEHICLE_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_ID);
			}

			sb.append("|");

			if (STATE_REGISTRATION == null) {
				sb.append("<null>");
			} else {
				sb.append(STATE_REGISTRATION);
			}

			sb.append("|");

			if (VEHICLE_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE);
			}

			sb.append("|");

			if (VEHICLE_MAKE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MAKE);
			}

			sb.append("|");

			if (VEHICLE_MODEL == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MODEL);
			}

			sb.append("|");

			if (VEHICLE_YEAR == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_YEAR);
			}

			sb.append("|");

			if (TRAVEL_DIRECTION == null) {
				sb.append("<null>");
			} else {
				sb.append(TRAVEL_DIRECTION);
			}

			sb.append("|");

			if (VEHICLE_OCCUPANTS == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_OCCUPANTS);
			}

			sb.append("|");

			if (DRIVER_SEX == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_SEX);
			}

			sb.append("|");

			if (DRIVER_LICENSE_STATUS == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_STATUS);
			}

			sb.append("|");

			if (DRIVER_LICENSE_JURISDICTION == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_JURISDICTION);
			}

			sb.append("|");

			if (PRE_CRASH == null) {
				sb.append("<null>");
			} else {
				sb.append(PRE_CRASH);
			}

			sb.append("|");

			if (POINT_OF_IMPACT == null) {
				sb.append("<null>");
			} else {
				sb.append(POINT_OF_IMPACT);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_1);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_2);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_3 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_3);
			}

			sb.append("|");

			if (PUBLIC_PROPERTY_DAMAGE == null) {
				sb.append("<null>");
			} else {
				sb.append(PUBLIC_PROPERTY_DAMAGE);
			}

			sb.append("|");

			if (PUBLIC_PROPERTY_DAMAGE_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(PUBLIC_PROPERTY_DAMAGE_TYPE);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_1);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_2);
			}

			sb.append("|");

			if (DI_PID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_PID);
			}

			sb.append("|");

			if (DI_Create_Date == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Create_Date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(outStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_MOTOR_LoadToStgVehicle = new byte[0];
		static byte[] commonByteArray_MOTOR_LoadToStgVehicle = new byte[0];

		public Integer UNIQUE_ID;

		public Integer getUNIQUE_ID() {
			return this.UNIQUE_ID;
		}

		public Integer COLLISION_ID;

		public Integer getCOLLISION_ID() {
			return this.COLLISION_ID;
		}

		public String CRASH_DATE;

		public String getCRASH_DATE() {
			return this.CRASH_DATE;
		}

		public String CRASH_TIME;

		public String getCRASH_TIME() {
			return this.CRASH_TIME;
		}

		public String VEHICLE_ID;

		public String getVEHICLE_ID() {
			return this.VEHICLE_ID;
		}

		public String STATE_REGISTRATION;

		public String getSTATE_REGISTRATION() {
			return this.STATE_REGISTRATION;
		}

		public String VEHICLE_TYPE;

		public String getVEHICLE_TYPE() {
			return this.VEHICLE_TYPE;
		}

		public String VEHICLE_MAKE;

		public String getVEHICLE_MAKE() {
			return this.VEHICLE_MAKE;
		}

		public String VEHICLE_MODEL;

		public String getVEHICLE_MODEL() {
			return this.VEHICLE_MODEL;
		}

		public String VEHICLE_YEAR;

		public String getVEHICLE_YEAR() {
			return this.VEHICLE_YEAR;
		}

		public String TRAVEL_DIRECTION;

		public String getTRAVEL_DIRECTION() {
			return this.TRAVEL_DIRECTION;
		}

		public String VEHICLE_OCCUPANTS;

		public String getVEHICLE_OCCUPANTS() {
			return this.VEHICLE_OCCUPANTS;
		}

		public String DRIVER_SEX;

		public String getDRIVER_SEX() {
			return this.DRIVER_SEX;
		}

		public String DRIVER_LICENSE_STATUS;

		public String getDRIVER_LICENSE_STATUS() {
			return this.DRIVER_LICENSE_STATUS;
		}

		public String DRIVER_LICENSE_JURISDICTION;

		public String getDRIVER_LICENSE_JURISDICTION() {
			return this.DRIVER_LICENSE_JURISDICTION;
		}

		public String PRE_CRASH;

		public String getPRE_CRASH() {
			return this.PRE_CRASH;
		}

		public String POINT_OF_IMPACT;

		public String getPOINT_OF_IMPACT() {
			return this.POINT_OF_IMPACT;
		}

		public String VEHICLE_DAMAGE;

		public String getVEHICLE_DAMAGE() {
			return this.VEHICLE_DAMAGE;
		}

		public String VEHICLE_DAMAGE_1;

		public String getVEHICLE_DAMAGE_1() {
			return this.VEHICLE_DAMAGE_1;
		}

		public String VEHICLE_DAMAGE_2;

		public String getVEHICLE_DAMAGE_2() {
			return this.VEHICLE_DAMAGE_2;
		}

		public String VEHICLE_DAMAGE_3;

		public String getVEHICLE_DAMAGE_3() {
			return this.VEHICLE_DAMAGE_3;
		}

		public String PUBLIC_PROPERTY_DAMAGE;

		public String getPUBLIC_PROPERTY_DAMAGE() {
			return this.PUBLIC_PROPERTY_DAMAGE;
		}

		public String PUBLIC_PROPERTY_DAMAGE_TYPE;

		public String getPUBLIC_PROPERTY_DAMAGE_TYPE() {
			return this.PUBLIC_PROPERTY_DAMAGE_TYPE;
		}

		public String CONTRIBUTING_FACTOR_1;

		public String getCONTRIBUTING_FACTOR_1() {
			return this.CONTRIBUTING_FACTOR_1;
		}

		public String CONTRIBUTING_FACTOR_2;

		public String getCONTRIBUTING_FACTOR_2() {
			return this.CONTRIBUTING_FACTOR_2;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MOTOR_LoadToStgVehicle.length) {
					if (length < 1024 && commonByteArray_MOTOR_LoadToStgVehicle.length == 0) {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[1024];
					} else {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_MOTOR_LoadToStgVehicle, 0, length);
				strReturn = new String(commonByteArray_MOTOR_LoadToStgVehicle, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_MOTOR_LoadToStgVehicle.length) {
					if (length < 1024 && commonByteArray_MOTOR_LoadToStgVehicle.length == 0) {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[1024];
					} else {
						commonByteArray_MOTOR_LoadToStgVehicle = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_MOTOR_LoadToStgVehicle, 0, length);
				strReturn = new String(commonByteArray_MOTOR_LoadToStgVehicle, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_MOTOR_LoadToStgVehicle) {

				try {

					int length = 0;

					this.UNIQUE_ID = readInteger(dis);

					this.COLLISION_ID = readInteger(dis);

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.VEHICLE_ID = readString(dis);

					this.STATE_REGISTRATION = readString(dis);

					this.VEHICLE_TYPE = readString(dis);

					this.VEHICLE_MAKE = readString(dis);

					this.VEHICLE_MODEL = readString(dis);

					this.VEHICLE_YEAR = readString(dis);

					this.TRAVEL_DIRECTION = readString(dis);

					this.VEHICLE_OCCUPANTS = readString(dis);

					this.DRIVER_SEX = readString(dis);

					this.DRIVER_LICENSE_STATUS = readString(dis);

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

					this.PRE_CRASH = readString(dis);

					this.POINT_OF_IMPACT = readString(dis);

					this.VEHICLE_DAMAGE = readString(dis);

					this.VEHICLE_DAMAGE_1 = readString(dis);

					this.VEHICLE_DAMAGE_2 = readString(dis);

					this.VEHICLE_DAMAGE_3 = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE_TYPE = readString(dis);

					this.CONTRIBUTING_FACTOR_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_2 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_MOTOR_LoadToStgVehicle) {

				try {

					int length = 0;

					this.UNIQUE_ID = readInteger(dis);

					this.COLLISION_ID = readInteger(dis);

					this.CRASH_DATE = readString(dis);

					this.CRASH_TIME = readString(dis);

					this.VEHICLE_ID = readString(dis);

					this.STATE_REGISTRATION = readString(dis);

					this.VEHICLE_TYPE = readString(dis);

					this.VEHICLE_MAKE = readString(dis);

					this.VEHICLE_MODEL = readString(dis);

					this.VEHICLE_YEAR = readString(dis);

					this.TRAVEL_DIRECTION = readString(dis);

					this.VEHICLE_OCCUPANTS = readString(dis);

					this.DRIVER_SEX = readString(dis);

					this.DRIVER_LICENSE_STATUS = readString(dis);

					this.DRIVER_LICENSE_JURISDICTION = readString(dis);

					this.PRE_CRASH = readString(dis);

					this.POINT_OF_IMPACT = readString(dis);

					this.VEHICLE_DAMAGE = readString(dis);

					this.VEHICLE_DAMAGE_1 = readString(dis);

					this.VEHICLE_DAMAGE_2 = readString(dis);

					this.VEHICLE_DAMAGE_3 = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE = readString(dis);

					this.PUBLIC_PROPERTY_DAMAGE_TYPE = readString(dis);

					this.CONTRIBUTING_FACTOR_1 = readString(dis);

					this.CONTRIBUTING_FACTOR_2 = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.UNIQUE_ID, dos);

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.VEHICLE_ID, dos);

				// String

				writeString(this.STATE_REGISTRATION, dos);

				// String

				writeString(this.VEHICLE_TYPE, dos);

				// String

				writeString(this.VEHICLE_MAKE, dos);

				// String

				writeString(this.VEHICLE_MODEL, dos);

				// String

				writeString(this.VEHICLE_YEAR, dos);

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

				// String

				writeString(this.VEHICLE_OCCUPANTS, dos);

				// String

				writeString(this.DRIVER_SEX, dos);

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

				// String

				writeString(this.PRE_CRASH, dos);

				// String

				writeString(this.POINT_OF_IMPACT, dos);

				// String

				writeString(this.VEHICLE_DAMAGE, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_1, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_2, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_3, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE_TYPE, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_2, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.UNIQUE_ID, dos);

				// Integer

				writeInteger(this.COLLISION_ID, dos);

				// String

				writeString(this.CRASH_DATE, dos);

				// String

				writeString(this.CRASH_TIME, dos);

				// String

				writeString(this.VEHICLE_ID, dos);

				// String

				writeString(this.STATE_REGISTRATION, dos);

				// String

				writeString(this.VEHICLE_TYPE, dos);

				// String

				writeString(this.VEHICLE_MAKE, dos);

				// String

				writeString(this.VEHICLE_MODEL, dos);

				// String

				writeString(this.VEHICLE_YEAR, dos);

				// String

				writeString(this.TRAVEL_DIRECTION, dos);

				// String

				writeString(this.VEHICLE_OCCUPANTS, dos);

				// String

				writeString(this.DRIVER_SEX, dos);

				// String

				writeString(this.DRIVER_LICENSE_STATUS, dos);

				// String

				writeString(this.DRIVER_LICENSE_JURISDICTION, dos);

				// String

				writeString(this.PRE_CRASH, dos);

				// String

				writeString(this.POINT_OF_IMPACT, dos);

				// String

				writeString(this.VEHICLE_DAMAGE, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_1, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_2, dos);

				// String

				writeString(this.VEHICLE_DAMAGE_3, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE, dos);

				// String

				writeString(this.PUBLIC_PROPERTY_DAMAGE_TYPE, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_1, dos);

				// String

				writeString(this.CONTRIBUTING_FACTOR_2, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("UNIQUE_ID=" + String.valueOf(UNIQUE_ID));
			sb.append(",COLLISION_ID=" + String.valueOf(COLLISION_ID));
			sb.append(",CRASH_DATE=" + CRASH_DATE);
			sb.append(",CRASH_TIME=" + CRASH_TIME);
			sb.append(",VEHICLE_ID=" + VEHICLE_ID);
			sb.append(",STATE_REGISTRATION=" + STATE_REGISTRATION);
			sb.append(",VEHICLE_TYPE=" + VEHICLE_TYPE);
			sb.append(",VEHICLE_MAKE=" + VEHICLE_MAKE);
			sb.append(",VEHICLE_MODEL=" + VEHICLE_MODEL);
			sb.append(",VEHICLE_YEAR=" + VEHICLE_YEAR);
			sb.append(",TRAVEL_DIRECTION=" + TRAVEL_DIRECTION);
			sb.append(",VEHICLE_OCCUPANTS=" + VEHICLE_OCCUPANTS);
			sb.append(",DRIVER_SEX=" + DRIVER_SEX);
			sb.append(",DRIVER_LICENSE_STATUS=" + DRIVER_LICENSE_STATUS);
			sb.append(",DRIVER_LICENSE_JURISDICTION=" + DRIVER_LICENSE_JURISDICTION);
			sb.append(",PRE_CRASH=" + PRE_CRASH);
			sb.append(",POINT_OF_IMPACT=" + POINT_OF_IMPACT);
			sb.append(",VEHICLE_DAMAGE=" + VEHICLE_DAMAGE);
			sb.append(",VEHICLE_DAMAGE_1=" + VEHICLE_DAMAGE_1);
			sb.append(",VEHICLE_DAMAGE_2=" + VEHICLE_DAMAGE_2);
			sb.append(",VEHICLE_DAMAGE_3=" + VEHICLE_DAMAGE_3);
			sb.append(",PUBLIC_PROPERTY_DAMAGE=" + PUBLIC_PROPERTY_DAMAGE);
			sb.append(",PUBLIC_PROPERTY_DAMAGE_TYPE=" + PUBLIC_PROPERTY_DAMAGE_TYPE);
			sb.append(",CONTRIBUTING_FACTOR_1=" + CONTRIBUTING_FACTOR_1);
			sb.append(",CONTRIBUTING_FACTOR_2=" + CONTRIBUTING_FACTOR_2);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (UNIQUE_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(UNIQUE_ID);
			}

			sb.append("|");

			if (COLLISION_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(COLLISION_ID);
			}

			sb.append("|");

			if (CRASH_DATE == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_DATE);
			}

			sb.append("|");

			if (CRASH_TIME == null) {
				sb.append("<null>");
			} else {
				sb.append(CRASH_TIME);
			}

			sb.append("|");

			if (VEHICLE_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_ID);
			}

			sb.append("|");

			if (STATE_REGISTRATION == null) {
				sb.append("<null>");
			} else {
				sb.append(STATE_REGISTRATION);
			}

			sb.append("|");

			if (VEHICLE_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_TYPE);
			}

			sb.append("|");

			if (VEHICLE_MAKE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MAKE);
			}

			sb.append("|");

			if (VEHICLE_MODEL == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_MODEL);
			}

			sb.append("|");

			if (VEHICLE_YEAR == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_YEAR);
			}

			sb.append("|");

			if (TRAVEL_DIRECTION == null) {
				sb.append("<null>");
			} else {
				sb.append(TRAVEL_DIRECTION);
			}

			sb.append("|");

			if (VEHICLE_OCCUPANTS == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_OCCUPANTS);
			}

			sb.append("|");

			if (DRIVER_SEX == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_SEX);
			}

			sb.append("|");

			if (DRIVER_LICENSE_STATUS == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_STATUS);
			}

			sb.append("|");

			if (DRIVER_LICENSE_JURISDICTION == null) {
				sb.append("<null>");
			} else {
				sb.append(DRIVER_LICENSE_JURISDICTION);
			}

			sb.append("|");

			if (PRE_CRASH == null) {
				sb.append("<null>");
			} else {
				sb.append(PRE_CRASH);
			}

			sb.append("|");

			if (POINT_OF_IMPACT == null) {
				sb.append("<null>");
			} else {
				sb.append(POINT_OF_IMPACT);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_1);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_2);
			}

			sb.append("|");

			if (VEHICLE_DAMAGE_3 == null) {
				sb.append("<null>");
			} else {
				sb.append(VEHICLE_DAMAGE_3);
			}

			sb.append("|");

			if (PUBLIC_PROPERTY_DAMAGE == null) {
				sb.append("<null>");
			} else {
				sb.append(PUBLIC_PROPERTY_DAMAGE);
			}

			sb.append("|");

			if (PUBLIC_PROPERTY_DAMAGE_TYPE == null) {
				sb.append("<null>");
			} else {
				sb.append(PUBLIC_PROPERTY_DAMAGE_TYPE);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_1 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_1);
			}

			sb.append("|");

			if (CONTRIBUTING_FACTOR_2 == null) {
				sb.append("<null>");
			} else {
				sb.append(CONTRIBUTING_FACTOR_2);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row3Struct row3 = new row3Struct();
				outStruct out = new outStruct();

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "out");
				}

				int tos_count_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
							log4jParamters_tDBOutput_1.append("Parameters:");
							log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DRIVER" + " = " + "MSSQL_PROP");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("HOST" + " = " + "\"MYWATERCOLOF781\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DBNAME" + " = " + "\"Motor\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USER" + " = " + "\"dongxuejiaonew\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:Y0xCPhLqkuqfFr7JNA9V83sLY6+PmoWn0wNXYp+z1bdmGVxwevfFdDwRFQ==")
									.substring(0, 4) + "...");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"stg_nyc_mv_collision_vehicles\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "DROP_IF_EXISTS_AND_CREATE");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SPECIFY_IDENTITY_FIELD" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ACTIVE_DIR_AUTH" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("BATCH_SIZE" + " = " + "10000");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_1 - " + (log4jParamters_tDBOutput_1));
						}
					}
					new BytesLimit65535_tDBOutput_1().limitLog4jByte();
				}

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rowsToCommitCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;
				String dbschema_tDBOutput_1 = null;
				String tableName_tDBOutput_1 = null;
				boolean whetherReject_tDBOutput_1 = false;

				java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
				long year1_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_1;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_1 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tDBOutput_1 = null;
				String dbUser_tDBOutput_1 = null;
				dbschema_tDBOutput_1 = "";
				String driverClass_tDBOutput_1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_1) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_1);
				String port_tDBOutput_1 = "1433";
				String dbname_tDBOutput_1 = "Motor";
				String url_tDBOutput_1 = "jdbc:sqlserver://" + "MYWATERCOLOF781";
				if (!"".equals(port_tDBOutput_1)) {
					url_tDBOutput_1 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_1)) {
					url_tDBOutput_1 += ";databaseName=" + "Motor";

				}
				url_tDBOutput_1 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_1 = "dongxuejiaonew";

				final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:DwStSbQ3j2E8jsKegHIpFXcg+AgdrLxDULDO+FI2+1mXak6OBRQtnzSLYw==");

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection attempts to '") + (url_tDBOutput_1)
							+ ("' with the username '") + (dbUser_tDBOutput_1) + ("'."));
				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, dbUser_tDBOutput_1,
						dbPwd_tDBOutput_1);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to '") + (url_tDBOutput_1) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);

				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_1.getAutoCommit()) + ("'."));
				int batchSize_tDBOutput_1 = 10000;
				int batchSizeCounter_tDBOutput_1 = 0;

				if (dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
					tableName_tDBOutput_1 = "stg_nyc_mv_collision_vehicles";
				} else {
					tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "].[" + "stg_nyc_mv_collision_vehicles";
				}
				int count_tDBOutput_1 = 0;

				boolean whetherExist_tDBOutput_1 = false;
				try (java.sql.Statement isExistStmt_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
					try {
						isExistStmt_tDBOutput_1.execute("SELECT TOP 1 1 FROM [" + tableName_tDBOutput_1 + "]");
						whetherExist_tDBOutput_1 = true;
					} catch (java.lang.Exception e) {
						globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());
						whetherExist_tDBOutput_1 = false;
					}
				}
				if (whetherExist_tDBOutput_1) {
					try (java.sql.Statement stmtDrop_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Dropping") + (" table '")
									+ ("[" + tableName_tDBOutput_1 + "]") + ("'."));
						stmtDrop_tDBOutput_1.execute("DROP TABLE [" + tableName_tDBOutput_1 + "]");
						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Drop") + (" table '") + ("[" + tableName_tDBOutput_1 + "]")
									+ ("' has succeeded."));
					}
				}
				try (java.sql.Statement stmtCreate_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Creating") + (" table '") + ("[" + tableName_tDBOutput_1 + "]")
								+ ("'."));
					stmtCreate_tDBOutput_1.execute("CREATE TABLE [" + tableName_tDBOutput_1
							+ "]([UNIQUE_ID] INT ,[COLLISION_ID] INT ,[CRASH_DATE] VARCHAR(100)  ,[CRASH_TIME] VARCHAR(100)  ,[VEHICLE_ID] VARCHAR(100)  ,[STATE_REGISTRATION] VARCHAR(100)  ,[VEHICLE_TYPE] VARCHAR(100)  ,[VEHICLE_MAKE] VARCHAR(100)  ,[VEHICLE_MODEL] VARCHAR(100)  ,[VEHICLE_YEAR] VARCHAR(100)  ,[TRAVEL_DIRECTION] VARCHAR(100)  ,[VEHICLE_OCCUPANTS] VARCHAR(100)  ,[DRIVER_SEX] VARCHAR(100)  ,[DRIVER_LICENSE_STATUS] VARCHAR(100)  ,[DRIVER_LICENSE_JURISDICTION] VARCHAR(100)  ,[PRE_CRASH] VARCHAR(100)  ,[POINT_OF_IMPACT] VARCHAR(100)  ,[VEHICLE_DAMAGE] VARCHAR(100)  ,[VEHICLE_DAMAGE_1] VARCHAR(100)  ,[VEHICLE_DAMAGE_2] VARCHAR(100)  ,[VEHICLE_DAMAGE_3] VARCHAR(100)  ,[PUBLIC_PROPERTY_DAMAGE] VARCHAR(100)  ,[PUBLIC_PROPERTY_DAMAGE_TYPE] VARCHAR(100)  ,[CONTRIBUTING_FACTOR_1] VARCHAR(100)  ,[CONTRIBUTING_FACTOR_2] VARCHAR(100)  ,[DI_PID] VARCHAR(500)  ,[DI_Create_Date] DATETIME )");
					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Create") + (" table '") + ("[" + tableName_tDBOutput_1 + "]")
								+ ("' has succeeded."));
				}
				String insert_tDBOutput_1 = "INSERT INTO [" + tableName_tDBOutput_1
						+ "] ([UNIQUE_ID],[COLLISION_ID],[CRASH_DATE],[CRASH_TIME],[VEHICLE_ID],[STATE_REGISTRATION],[VEHICLE_TYPE],[VEHICLE_MAKE],[VEHICLE_MODEL],[VEHICLE_YEAR],[TRAVEL_DIRECTION],[VEHICLE_OCCUPANTS],[DRIVER_SEX],[DRIVER_LICENSE_STATUS],[DRIVER_LICENSE_JURISDICTION],[PRE_CRASH],[POINT_OF_IMPACT],[VEHICLE_DAMAGE],[VEHICLE_DAMAGE_1],[VEHICLE_DAMAGE_2],[VEHICLE_DAMAGE_3],[PUBLIC_PROPERTY_DAMAGE],[PUBLIC_PROPERTY_DAMAGE_TYPE],[CONTRIBUTING_FACTOR_1],[CONTRIBUTING_FACTOR_2],[DI_PID],[DI_Create_Date]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row3");
				}

				int tos_count_tMap_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_1 = new StringBuilder();
							log4jParamters_tMap_1.append("Parameters:");
							log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_1 - " + (log4jParamters_tMap_1));
						}
					}
					new BytesLimit65535_tMap_1().limitLog4jByte();
				}

// ###############################
// # Lookup's keys initialization
				int count_row3_tMap_1 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out_tMap_1 = 0;

				outStruct out_tmp = new outStruct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_2 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_2", false);
				start_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_2";

				int tos_count_tFileInputDelimited_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileInputDelimited_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileInputDelimited_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileInputDelimited_2 = new StringBuilder();
							log4jParamters_tFileInputDelimited_2.append("Parameters:");
							log4jParamters_tFileInputDelimited_2.append("FILENAME" + " = "
									+ "\"//Mac/Home/Downloads/Motor_Vehicle_Collisions_-_Vehicles.tsv\"");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("CSV_OPTION" + " = " + "false");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("ROWSEPARATOR" + " = " + "\"\\n\"");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("FIELDSEPARATOR" + " = " + "\"\\t\"");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("HEADER" + " = " + "1");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("FOOTER" + " = " + "0");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("LIMIT" + " = " + "");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("REMOVE_EMPTY_ROW" + " = " + "false");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("UNCOMPRESS" + " = " + "false");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("RANDOM" + " = " + "false");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("TRIMALL" + " = " + "false");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("TRIMSELECT" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("UNIQUE_ID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("COLLISION_ID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("CRASH_DATE")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("CRASH_TIME") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_ID") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("STATE_REGISTRATION") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_TYPE") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_MAKE") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_MODEL") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_YEAR") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("TRAVEL_DIRECTION") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_OCCUPANTS") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("DRIVER_SEX") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("DRIVER_LICENSE_STATUS") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("DRIVER_LICENSE_JURISDICTION") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("PRE_CRASH") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("POINT_OF_IMPACT")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE_1") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE_2") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("VEHICLE_DAMAGE_3") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PUBLIC_PROPERTY_DAMAGE") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PUBLIC_PROPERTY_DAMAGE_TYPE") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("CONTRIBUTING_FACTOR_1") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("CONTRIBUTING_FACTOR_2") + "}]");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("CHECK_FIELDS_NUM" + " = " + "false");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("CHECK_DATE" + " = " + "false");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("ENCODING" + " = " + "\"UTF-8\"");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("SPLITRECORD" + " = " + "false");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							log4jParamters_tFileInputDelimited_2.append("ENABLE_DECODE" + " = " + "false");
							log4jParamters_tFileInputDelimited_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileInputDelimited_2 - " + (log4jParamters_tFileInputDelimited_2));
						}
					}
					new BytesLimit65535_tFileInputDelimited_2().limitLog4jByte();
				}

				final routines.system.RowState rowstate_tFileInputDelimited_2 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_2 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_2 = null;
				int limit_tFileInputDelimited_2 = -1;
				try {

					Object filename_tFileInputDelimited_2 = "//Mac/Home/Downloads/Motor_Vehicle_Collisions_-_Vehicles.tsv";
					if (filename_tFileInputDelimited_2 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_2 = 0, random_value_tFileInputDelimited_2 = -1;
						if (footer_value_tFileInputDelimited_2 > 0 || random_value_tFileInputDelimited_2 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_2 = new org.talend.fileprocess.FileInputDelimited(
								"//Mac/Home/Downloads/Motor_Vehicle_Collisions_-_Vehicles.tsv", "UTF-8", "\t", "\n",
								false, 1, 0, limit_tFileInputDelimited_2, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE", e.getMessage());

						log.error("tFileInputDelimited_2 - " + e.getMessage());

						System.err.println(e.getMessage());

					}

					log.info("tFileInputDelimited_2 - Retrieving records from the datasource.");

					while (fid_tFileInputDelimited_2 != null && fid_tFileInputDelimited_2.nextRecord()) {
						rowstate_tFileInputDelimited_2.reset();

						row3 = null;

						boolean whetherReject_tFileInputDelimited_2 = false;
						row3 = new row3Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_2 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_2 = 0;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row3.UNIQUE_ID = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"UNIQUE_ID", "row3", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row3.UNIQUE_ID = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 1;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row3.COLLISION_ID = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"COLLISION_ID", "row3", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row3.COLLISION_ID = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 2;

							row3.CRASH_DATE = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 3;

							row3.CRASH_TIME = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 4;

							row3.VEHICLE_ID = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 5;

							row3.STATE_REGISTRATION = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 6;

							row3.VEHICLE_TYPE = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 7;

							row3.VEHICLE_MAKE = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 8;

							row3.VEHICLE_MODEL = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 9;

							row3.VEHICLE_YEAR = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 10;

							row3.TRAVEL_DIRECTION = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 11;

							row3.VEHICLE_OCCUPANTS = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 12;

							row3.DRIVER_SEX = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 13;

							row3.DRIVER_LICENSE_STATUS = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 14;

							row3.DRIVER_LICENSE_JURISDICTION = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 15;

							row3.PRE_CRASH = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 16;

							row3.POINT_OF_IMPACT = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 17;

							row3.VEHICLE_DAMAGE = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 18;

							row3.VEHICLE_DAMAGE_1 = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 19;

							row3.VEHICLE_DAMAGE_2 = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 20;

							row3.VEHICLE_DAMAGE_3 = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 21;

							row3.PUBLIC_PROPERTY_DAMAGE = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 22;

							row3.PUBLIC_PROPERTY_DAMAGE_TYPE = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 23;

							row3.CONTRIBUTING_FACTOR_1 = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 24;

							row3.CONTRIBUTING_FACTOR_2 = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							if (rowstate_tFileInputDelimited_2.getException() != null) {
								throw rowstate_tFileInputDelimited_2.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_2 = true;

							log.error("tFileInputDelimited_2 - " + e.getMessage());

							System.err.println(e.getMessage());
							row3 = null;

						}

						log.debug("tFileInputDelimited_2 - Retrieving the record "
								+ fid_tFileInputDelimited_2.getRowNumber() + ".");

						/**
						 * [tFileInputDelimited_2 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_2 main ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						tos_count_tFileInputDelimited_2++;

						/**
						 * [tFileInputDelimited_2 main ] stop
						 */

						/**
						 * [tFileInputDelimited_2 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						/**
						 * [tFileInputDelimited_2 process_data_begin ] stop
						 */
// Start of branch "row3"
						if (row3 != null) {

							/**
							 * [tMap_1 main ] start
							 */

							currentComponent = "tMap_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row3"

								);
							}

							if (log.isTraceEnabled()) {
								log.trace("row3 - " + (row3 == null ? "" : row3.toLogString()));
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_1 = false;
							boolean mainRowRejected_tMap_1 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
								// ###############################
								// # Output tables

								out = null;

// # Output table : 'out'
								count_out_tMap_1++;

								out_tmp.UNIQUE_ID = row3.UNIQUE_ID;
								out_tmp.COLLISION_ID = row3.COLLISION_ID;
								out_tmp.CRASH_DATE = row3.CRASH_DATE;
								out_tmp.CRASH_TIME = row3.CRASH_TIME;
								out_tmp.VEHICLE_ID = row3.VEHICLE_ID;
								out_tmp.STATE_REGISTRATION = row3.STATE_REGISTRATION;
								out_tmp.VEHICLE_TYPE = row3.VEHICLE_TYPE;
								out_tmp.VEHICLE_MAKE = row3.VEHICLE_MAKE;
								out_tmp.VEHICLE_MODEL = row3.VEHICLE_MODEL;
								out_tmp.VEHICLE_YEAR = row3.VEHICLE_YEAR;
								out_tmp.TRAVEL_DIRECTION = row3.TRAVEL_DIRECTION;
								out_tmp.VEHICLE_OCCUPANTS = row3.VEHICLE_OCCUPANTS;
								out_tmp.DRIVER_SEX = row3.DRIVER_SEX;
								out_tmp.DRIVER_LICENSE_STATUS = row3.DRIVER_LICENSE_STATUS;
								out_tmp.DRIVER_LICENSE_JURISDICTION = row3.DRIVER_LICENSE_JURISDICTION;
								out_tmp.PRE_CRASH = row3.PRE_CRASH;
								out_tmp.POINT_OF_IMPACT = row3.POINT_OF_IMPACT;
								out_tmp.VEHICLE_DAMAGE = row3.VEHICLE_DAMAGE;
								out_tmp.VEHICLE_DAMAGE_1 = row3.VEHICLE_DAMAGE_1;
								out_tmp.VEHICLE_DAMAGE_2 = row3.VEHICLE_DAMAGE_2;
								out_tmp.VEHICLE_DAMAGE_3 = row3.VEHICLE_DAMAGE_3;
								out_tmp.PUBLIC_PROPERTY_DAMAGE = row3.PUBLIC_PROPERTY_DAMAGE;
								out_tmp.PUBLIC_PROPERTY_DAMAGE_TYPE = row3.PUBLIC_PROPERTY_DAMAGE_TYPE;
								out_tmp.CONTRIBUTING_FACTOR_1 = row3.CONTRIBUTING_FACTOR_1;
								out_tmp.CONTRIBUTING_FACTOR_2 = row3.CONTRIBUTING_FACTOR_2;
								out_tmp.DI_PID = "LoadToMotorCollisionVehicle";
								out_tmp.DI_Create_Date = TalendDate.getCurrentDate();
								out = out_tmp;
								log.debug("tMap_1 - Outputting the record " + count_out_tMap_1
										+ " of the output table 'out'.");

// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_1 = false;

							tos_count_tMap_1++;

							/**
							 * [tMap_1 main ] stop
							 */

							/**
							 * [tMap_1 process_data_begin ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_begin ] stop
							 */
// Start of branch "out"
							if (out != null) {

								/**
								 * [tDBOutput_1 main ] start
								 */

								currentComponent = "tDBOutput_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "out"

									);
								}

								if (log.isTraceEnabled()) {
									log.trace("out - " + (out == null ? "" : out.toLogString()));
								}

								whetherReject_tDBOutput_1 = false;
								if (out.UNIQUE_ID == null) {
									pstmt_tDBOutput_1.setNull(1, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_1.setInt(1, out.UNIQUE_ID);
								}

								if (out.COLLISION_ID == null) {
									pstmt_tDBOutput_1.setNull(2, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_1.setInt(2, out.COLLISION_ID);
								}

								if (out.CRASH_DATE == null) {
									pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(3, out.CRASH_DATE);
								}

								if (out.CRASH_TIME == null) {
									pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(4, out.CRASH_TIME);
								}

								if (out.VEHICLE_ID == null) {
									pstmt_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(5, out.VEHICLE_ID);
								}

								if (out.STATE_REGISTRATION == null) {
									pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(6, out.STATE_REGISTRATION);
								}

								if (out.VEHICLE_TYPE == null) {
									pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(7, out.VEHICLE_TYPE);
								}

								if (out.VEHICLE_MAKE == null) {
									pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(8, out.VEHICLE_MAKE);
								}

								if (out.VEHICLE_MODEL == null) {
									pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(9, out.VEHICLE_MODEL);
								}

								if (out.VEHICLE_YEAR == null) {
									pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(10, out.VEHICLE_YEAR);
								}

								if (out.TRAVEL_DIRECTION == null) {
									pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(11, out.TRAVEL_DIRECTION);
								}

								if (out.VEHICLE_OCCUPANTS == null) {
									pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(12, out.VEHICLE_OCCUPANTS);
								}

								if (out.DRIVER_SEX == null) {
									pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(13, out.DRIVER_SEX);
								}

								if (out.DRIVER_LICENSE_STATUS == null) {
									pstmt_tDBOutput_1.setNull(14, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(14, out.DRIVER_LICENSE_STATUS);
								}

								if (out.DRIVER_LICENSE_JURISDICTION == null) {
									pstmt_tDBOutput_1.setNull(15, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(15, out.DRIVER_LICENSE_JURISDICTION);
								}

								if (out.PRE_CRASH == null) {
									pstmt_tDBOutput_1.setNull(16, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(16, out.PRE_CRASH);
								}

								if (out.POINT_OF_IMPACT == null) {
									pstmt_tDBOutput_1.setNull(17, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(17, out.POINT_OF_IMPACT);
								}

								if (out.VEHICLE_DAMAGE == null) {
									pstmt_tDBOutput_1.setNull(18, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(18, out.VEHICLE_DAMAGE);
								}

								if (out.VEHICLE_DAMAGE_1 == null) {
									pstmt_tDBOutput_1.setNull(19, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(19, out.VEHICLE_DAMAGE_1);
								}

								if (out.VEHICLE_DAMAGE_2 == null) {
									pstmt_tDBOutput_1.setNull(20, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(20, out.VEHICLE_DAMAGE_2);
								}

								if (out.VEHICLE_DAMAGE_3 == null) {
									pstmt_tDBOutput_1.setNull(21, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(21, out.VEHICLE_DAMAGE_3);
								}

								if (out.PUBLIC_PROPERTY_DAMAGE == null) {
									pstmt_tDBOutput_1.setNull(22, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(22, out.PUBLIC_PROPERTY_DAMAGE);
								}

								if (out.PUBLIC_PROPERTY_DAMAGE_TYPE == null) {
									pstmt_tDBOutput_1.setNull(23, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(23, out.PUBLIC_PROPERTY_DAMAGE_TYPE);
								}

								if (out.CONTRIBUTING_FACTOR_1 == null) {
									pstmt_tDBOutput_1.setNull(24, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(24, out.CONTRIBUTING_FACTOR_1);
								}

								if (out.CONTRIBUTING_FACTOR_2 == null) {
									pstmt_tDBOutput_1.setNull(25, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(25, out.CONTRIBUTING_FACTOR_2);
								}

								if (out.DI_PID == null) {
									pstmt_tDBOutput_1.setNull(26, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(26, out.DI_PID);
								}

								if (out.DI_Create_Date != null) {
									pstmt_tDBOutput_1.setTimestamp(27,
											new java.sql.Timestamp(out.DI_Create_Date.getTime()));
								} else {
									pstmt_tDBOutput_1.setNull(27, java.sql.Types.TIMESTAMP);
								}

								pstmt_tDBOutput_1.addBatch();
								nb_line_tDBOutput_1++;

								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Adding the record ") + (nb_line_tDBOutput_1)
											+ (" to the ") + ("INSERT") + (" batch."));
								batchSizeCounter_tDBOutput_1++;

								////////// batch execute by batch size///////
								class LimitBytesHelper_tDBOutput_1 {
									public int limitBytePart1(int counter, java.sql.PreparedStatement pstmt_tDBOutput_1)
											throws Exception {
										try {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT")
														+ (" batch."));
											for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
												if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
													break;
												}
												counter += countEach_tDBOutput_1;
											}

											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
														+ (" batch execution has succeeded."));
										} catch (java.sql.BatchUpdateException e) {
											globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

											int countSum_tDBOutput_1 = 0;
											for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
												counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
											}

											log.error("tDBOutput_1 - " + (e.getMessage()));
											System.err.println(e.getMessage());

										}
										return counter;
									}

									public int limitBytePart2(int counter, java.sql.PreparedStatement pstmt_tDBOutput_1)
											throws Exception {
										try {

											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT")
														+ (" batch."));
											for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
												if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
													break;
												}
												counter += countEach_tDBOutput_1;
											}

											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
														+ (" batch execution has succeeded."));
										} catch (java.sql.BatchUpdateException e) {
											globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

											for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
												counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
											}

											log.error("tDBOutput_1 - " + (e.getMessage()));
											System.err.println(e.getMessage());

										}
										return counter;
									}
								}
								if ((batchSize_tDBOutput_1 > 0)
										&& (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {

									insertedCount_tDBOutput_1 = new LimitBytesHelper_tDBOutput_1()
											.limitBytePart1(insertedCount_tDBOutput_1, pstmt_tDBOutput_1);
									rowsToCommitCount_tDBOutput_1 = insertedCount_tDBOutput_1;

									batchSizeCounter_tDBOutput_1 = 0;
								}

								//////////// commit every////////////

								commitCounter_tDBOutput_1++;
								if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
									if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {

										insertedCount_tDBOutput_1 = new LimitBytesHelper_tDBOutput_1()
												.limitBytePart1(insertedCount_tDBOutput_1, pstmt_tDBOutput_1);

										batchSizeCounter_tDBOutput_1 = 0;
									}
									if (rowsToCommitCount_tDBOutput_1 != 0) {

										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
													+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
									}
									conn_tDBOutput_1.commit();
									if (rowsToCommitCount_tDBOutput_1 != 0) {

										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
										rowsToCommitCount_tDBOutput_1 = 0;
									}
									commitCounter_tDBOutput_1 = 0;
								}

								tos_count_tDBOutput_1++;

								/**
								 * [tDBOutput_1 main ] stop
								 */

								/**
								 * [tDBOutput_1 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_1";

								/**
								 * [tDBOutput_1 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_1 process_data_end ] start
								 */

								currentComponent = "tDBOutput_1";

								/**
								 * [tDBOutput_1 process_data_end ] stop
								 */

							} // End of branch "out"

							/**
							 * [tMap_1 process_data_end ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_end ] stop
							 */

						} // End of branch "row3"

						/**
						 * [tFileInputDelimited_2 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						/**
						 * [tFileInputDelimited_2 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_2 end ] start
						 */

						currentComponent = "tFileInputDelimited_2";

					}
				} finally {
					if (!((Object) ("//Mac/Home/Downloads/Motor_Vehicle_Collisions_-_Vehicles.tsv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_2 != null) {
							fid_tFileInputDelimited_2.close();
						}
					}
					if (fid_tFileInputDelimited_2 != null) {
						globalMap.put("tFileInputDelimited_2_NB_LINE", fid_tFileInputDelimited_2.getRowNumber());

						log.info("tFileInputDelimited_2 - Retrieved records count: "
								+ fid_tFileInputDelimited_2.getRowNumber() + ".");

					}
				}

				if (log.isDebugEnabled())
					log.debug("tFileInputDelimited_2 - " + ("Done."));

				ok_Hash.put("tFileInputDelimited_2", true);
				end_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_2 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'out': " + count_out_tMap_1 + ".");

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row3");
				}

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Done."));

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					int countSum_tDBOutput_1 = 0;
					if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
							if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
								break;
							}
							countSum_tDBOutput_1 += countEach_tDBOutput_1;
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));
					}

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

				} catch (java.sql.BatchUpdateException e) {
					globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_1 = 0;
					for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					log.error("tDBOutput_1 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				if (pstmt_tDBOutput_1 != null) {

					pstmt_tDBOutput_1.close();
					resourceMap.remove("pstmt_tDBOutput_1");

				}
				resourceMap.put("statementClosed_tDBOutput_1", true);
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
				}
				conn_tDBOutput_1.commit();
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_1 = 0;
				}
				commitCounter_tDBOutput_1 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
				conn_tDBOutput_1.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_1)
							+ (" record(s)."));

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "out");
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Done."));

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_2 finally ] start
				 */

				currentComponent = "tFileInputDelimited_2";

				/**
				 * [tFileInputDelimited_2 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
						if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_1")) != null) {
							pstmtToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_1")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_1.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								log.error("tDBOutput_1 - " + (errorMessage_tDBOutput_1));
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final LoadToStgVehicle LoadToStgVehicleClass = new LoadToStgVehicle();

		int exitCode = LoadToStgVehicleClass.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'LoadToStgVehicle' - Done.");
		}

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (!"".equals(log4jLevel)) {

			if ("trace".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.OFF);
			}
			org.apache.logging.log4j.core.config.Configurator
					.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());

		}
		log.info("TalendJob: 'LoadToStgVehicle' - Start.");

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = LoadToStgVehicle.class.getClassLoader()
					.getResourceAsStream("motor/loadtostgvehicle_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = LoadToStgVehicle.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileInputDelimited_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_1) {
			globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_1.printStackTrace();

		}
		try {
			errorCode = null;
			tFileInputDelimited_2Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_2) {
			globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_2.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println(
					(endUsedMemory - startUsedMemory) + " bytes memory increase when running : LoadToStgVehicle");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 211027 characters generated by Talend Real-time Big Data Platform on the
 * November 21, 2022 at 10:40:41 PM EST
 ************************************************************************************************/